// Job queue on PostgreSQL (pg-boss). Every queue is declared here with the data its jobs carry and its
// retry policy: business code enqueues by name, the worker registers one handler per queue (jobs/*.ts),
// and both sides are checked against JobData, so a payload cannot drift between producer and consumer.
// A module declares its own queues (modules.ts ModuleQueue), typed by the queue in the same way.
import { PgBoss, type SendOptions, type WorkOptions } from "pg-boss";
import { config } from "../config.ts";
import { sql, type Db } from "../db.ts";
import { shutdownSignal } from "../lib/shutdown.ts";
import { failureKind } from "../providers/receipts.ts";
import { logError } from "../lib/log-error.ts";
import { serverModules, type ModuleQueue } from "../modules.ts";
import { runOwner } from "./runs.ts";
export { shutdownSignal } from "../lib/shutdown.ts";

let boss: PgBoss | null = null;
let starting: Promise<PgBoss> | null = null;

export interface JobData {
  "content.analyze": { articleId: string; attemptTag?: string };
  "content.extract-body": { articleId: string };
  "events.group": { articleId: string; signalOnly?: boolean; regroup?: boolean };
  "events.digest": { storyId: number };
  "sources.fetch": { sourceId: string; force?: boolean };
  "sources.fetch-x": { key: string; sourceIds: string[] };
  "sources.mp": { sourceId: string; reason?: "schedule" | "manual" };
  "notify.selected": { articleId: string; attempt?: number };
  "publication.republish-source": { sourceId: string };
  "media.prepare": { articleId: string } | { url: string; mode: string; format?: "avif" };
}
export type QueueName = keyof JobData;

export const QUEUES = {
  analyze: "content.analyze",
  extractBody: "content.extract-body",
  group: "events.group",
  digest: "events.digest",
  fetchSource: "sources.fetch",
  fetchXShard: "sources.fetch-x",
  mpCheck: "sources.mp",
  notifySelected: "notify.selected",
  republishSource: "publication.republish-source",
  prepareMedia: "media.prepare",
} as const satisfies Record<string, QueueName>;

/**
 * Queue order (pg-boss serves higher priority first): live work before history, so a new source's
 * first import or a backfill never holds up today's news; discussion evidence waits behind reports
 * in the serial grouping queue, history behind both.
 */
export function articlePriority({ historical, signal = false }: { historical: boolean; signal?: boolean }): number {
  return historical ? -2 : signal ? -1 : 0;
}

export type QueueOptions = NonNullable<Parameters<PgBoss["createQueue"]>[1]>;

/** Queue definitions in one place; created on first use by any process. */
const QUEUE_OPTIONS: Record<QueueName, QueueOptions> = {
  [QUEUES.analyze]: { policy: "short", retryLimit: 4, retryDelay: 30, retryBackoff: true, expireInSeconds: 600 },
  [QUEUES.extractBody]: { policy: "short", retryLimit: 2, retryDelay: 120, expireInSeconds: 300 },
  [QUEUES.group]: { policy: "short", retryLimit: 4, retryDelay: 20, retryBackoff: true, expireInSeconds: 600 },
  [QUEUES.digest]: { policy: "short", retryLimit: 3, retryDelay: 60, retryBackoff: true, expireInSeconds: 900 },
  [QUEUES.fetchSource]: { policy: "short", retryLimit: 0, expireInSeconds: 600 },
  [QUEUES.fetchXShard]: { policy: "short", retryLimit: 0, expireInSeconds: 900 },
  [QUEUES.mpCheck]: { policy: "short", retryLimit: 3, retryDelay: 60, retryBackoff: true, expireInSeconds: 600 },
  [QUEUES.notifySelected]: { policy: "short", retryLimit: 0, expireInSeconds: 300 },
  [QUEUES.republishSource]: { policy: "short", retryLimit: 2, retryDelay: 60, expireInSeconds: 3600 },
  [QUEUES.prepareMedia]: { policy: "short", retryLimit: 1, retryDelay: 120, expireInSeconds: 600 },
};

const ensured = new Set<string>();

/** Only the worker owns timer dispatch and queue maintenance; other processes submit work. */
export async function getBoss({ supervise = false } = {}): Promise<PgBoss> {
  if (boss) return boss;
  starting ??= (async () => {
    const b = new PgBoss({ connectionString: config.databaseUrl, max: 4, schema: "pgboss", application_name: "aihot-jobs", schedule: supervise, supervise });
    b.on("error", (err) => console.error("[pg-boss]", logError(err)));
    try {
      await b.start();
      boss = b;
      return b;
    } catch (error) {
      await b.stop({ graceful: false }).catch((cleanup) => console.error("[pg-boss] startup cleanup", logError(cleanup)));
      throw error;
    } finally {
      // A temporary connection error must not leave every caller sharing a rejected promise.
      starting = null;
    }
  })();
  return starting;
}

/** Let in-flight backups and paid calls finish; process supervisors wait longer for cleanup. */
export const STOP_TIMEOUT_MS = 470_000;

export async function stopBoss(): Promise<void> {
  shutdownSignal.abort();
  if (boss) {
    const draining = boss;
    const started = performance.now();
    const report = (phase: "start" | "waiting" | "complete") => {
      // Read this process's workers, including scheduled/internal work. Never log payloads or errors:
      // they can contain credentials and reader data. Multiple workers on one queue count together.
      const queues = new Map<string, { queue: string; count: number; oldestMs: number }>();
      const now = Date.now();
      for (const work of draining.getWipData({ includeInternal: true })) {
        if (!work.count) continue;
        const item = queues.get(work.name) ?? { queue: work.name, count: 0, oldestMs: 0 };
        item.count += work.count;
        item.oldestMs = Math.max(item.oldestMs, work.lastJobStartedOn === null ? 0 : Math.max(0, now - work.lastJobStartedOn));
        queues.set(work.name, item);
      }
      const jobs = [...queues.values()].sort((a, b) => a.queue.localeCompare(b.queue));
      console.log(JSON.stringify({ level: "info", msg: "queue drain", phase,
        elapsedMs: Math.round(performance.now() - started), count: jobs.reduce((sum, job) => sum + job.count, 0), jobs }));
    };
    report("start");
    const progress = setInterval(() => report("waiting"), 10_000);
    progress.unref();
    try {
      await draining.stop({ graceful: true, timeout: STOP_TIMEOUT_MS });
      report("complete");
    } finally {
      clearInterval(progress);
    }
  }
  boss = null;
  starting = null;
}

export async function ensureQueue(name: string, options: QueueOptions = QUEUE_OPTIONS[name as QueueName] ?? {}): Promise<void> {
  if (ensured.has(name)) return;
  const b = await getBoss();
  const existing = await b.getQueue(name);
  if (!existing) await b.createQueue(name, options);
  ensured.add(name);
}

function queueDb(tx: Db) {
  return { executeSql: async (text: string, values?: unknown[]) => ({ rows: await tx.unsafe(text, (values ?? []) as never[]) }) };
}

/** Enqueues a job. With `tx`, the job commits atomically with the caller's business write. */
export async function enqueue<Q extends QueueName>(name: Q, data: JobData[Q], options: SendOptions = {}, tx?: Db): Promise<string | null> {
  await ensureQueue(name);
  const b = await getBoss();
  return b.send(name, data, tx ? { ...options, db: queueDb(tx) } : options);
}

/** Enqueues a job on a module's queue. With `tx`, the job commits atomically with the caller's business write. */
export async function enqueueOn<T extends object>(queue: ModuleQueue<T>, data: T, options: SendOptions = {}, tx?: Db): Promise<string | null> {
  await ensureQueue(queue.name, queue.options);
  const b = await getBoss();
  return b.send(queue.name, data, tx ? { ...options, db: queueDb(tx) } : options);
}

/** A receipt release also wakes jobs (e.g. grouping/embeddings) that exhausted their queue retries.
 * The release must follow the failed attempt's start: it may arrive while that attempt is finishing,
 * but cannot keep reviving attempts started after it.
 * Reading the durable audit also recovers a crash between the release and this sweep.
 */
export async function retryReleasedReceiptJobs(): Promise<number> {
  const b = await getBoss();
  return sql.begin(async (tx) => {
    const jobs = await tx<{ id: string; name: string }[]>`
      SELECT j.id, j.name FROM pgboss.job j
      WHERE j.state = 'failed'
        AND EXISTS (SELECT 1 FROM audit_log a WHERE a.action = 'receipt.release'
                    AND a.subject = 'receipt:' || (j.output->>'receiptId') AND a.created_at > j.started_on)
      ORDER BY j.completed_on LIMIT 200 FOR UPDATE OF j SKIP LOCKED`;
    for (const job of jobs) await b.retry(job.name, job.id, { db: queueDb(tx) });
    return jobs.length;
  });
}

/** The worker's handler for one queue (jobs/*.ts), called with each job's data. */
export async function work<Q extends QueueName>(boss: PgBoss, name: Q, options: WorkOptions, handler: (data: JobData[Q]) => Promise<unknown>): Promise<void> {
  await ensureQueue(name);
  await boss.work<JobData[Q]>(name, options, async ([job]) => (job ? handler(job.data) : undefined));
}

/** The worker's handlers for the site's modules' queues. */
export async function workModuleQueues(boss: PgBoss): Promise<void> {
  for (const queue of serverModules().flatMap((m) => m.queues ?? [])) {
    await ensureQueue(queue.name, queue.options);
    await boss.work(queue.name, { ...queue.worker, perJobResults: true }, async (jobs) => {
      const output = await queue.run(jobs.map(job => job.data) as never[]);
      return jobs.map(job => ({ id: job.id, status: "completed" as const, output }));
    });
  }
}

// Scheduled task bookkeeping: every run leaves a row, so operators see the latest result.

export async function recordRun<T>(job: string, fn: () => Promise<T>): Promise<T> {
  const [row] = await sql<{ id: number }[]>`INSERT INTO job_runs (job, detail) VALUES (${job}, ${sql.json({ owner: await runOwner() })}) RETURNING id`;
  try {
    const result = await fn();
    const detail = result && typeof result === "object" && !Array.isArray(result) ? result : { result };
    await sql`UPDATE job_runs SET status = 'ok', finished_at = now(), detail = ${sql.json(detail as never)} || jsonb_build_object('owner', detail->'owner') WHERE id = ${row!.id} AND status = 'running'`;
    return result;
  } catch (error) {
    // A paid-call budget is an expected pause, not a failure: record it as skipped so the runs page
    // keeps its alarms for real failures. Other errors stay failures.
    const skipped = failureKind(error) === "budget";
    await sql`UPDATE job_runs SET status = ${skipped ? "skipped" : "failed"}, finished_at = now(), error = ${String(error).slice(0, 4000)} WHERE id = ${row!.id} AND status = 'running'`;
    throw error;
  }
}
