// Signed image proxy URLs. The address format and signing key stay stable, so proxy URLs
// already cached in full RSS and readers keep working: /api/img-proxy?u=&mode=&exp=&sig=
// sig = hex(HMAC-SHA256(IMG_PROXY_SIGN_SECRET, `${u}|${mode}|${exp}`)), sent as its first 16 hex
// digits (64 bits): the random digits cannot be compressed, and the full 64 made up about a tenth
// of a compressed list page. A full-length signature from an older URL is still accepted. A mode with
// the AVIF suffix (card-avif) is that rendition's AVIF variant and carries the rendition's signature.
import { createHmac, timingSafeEqual } from "node:crypto";
import * as cheerio from "cheerio";
import { config, credential } from "../config.ts";
import { normalizeVideos } from "../content/video.ts";
import { isNonArticleImage } from "../lib/image-url.ts";
import { isXVideoUrl } from "../lib/video-url.ts";
import { AVIF_MODE_SUFFIX, avifCandidates } from "@aihot/contracts/site";
import { AVIF_MODES, IMAGE_WIDTHS, RESPONSIVE_MODES, type ProxyMode, type ResponsiveImageKind } from "./renditions.ts";
export type { ProxyMode } from "./renditions.ts";

// A URL keeps its expiry for a whole day, so the edge and browsers can reuse one copy of an image all
// day; it stays valid for two to three days. Avatars (source icons and authors' pictures) are a small
// set that appears on every visit: they keep one address for 30 days, so a returning reader's browser
// still has them instead of downloading them again each day.
const WINDOW_SECONDS = 24 * 3600;
const AVATAR_WINDOW_SECONDS = 30 * 24 * 3600;
const LIFETIME_SECONDS = 48 * 3600;
const SIG_HEX = 16;
export const X_VIDEO_MODE = "x-video";
/** How long browsers and the edge may keep a proxied image: as long as an avatar keeps its address. */
export const LONGEST_CACHE_SECONDS = AVATAR_WINDOW_SECONDS;

function secret(): string {
  const s = credential("auth", "IMG_PROXY_SIGN_SECRET");
  if (!s) throw new Error("IMG_PROXY_SIGN_SECRET is not configured");
  return s;
}

export function signature(url: string, mode: string, exp: number | string): string {
  return createHmac("sha256", secret()).update(`${url}|${mode}|${exp}`).digest("hex").slice(0, SIG_HEX);
}

/** Expiry rounded up to a window boundary at least `lifetime` (48 h) ahead, so URLs stay cacheable. */
function proxyExpiry(nowMs: number, lifetimeSeconds: number, windowSeconds: number): number {
  return Math.ceil((nowMs / 1000 + lifetimeSeconds) / windowSeconds) * windowSeconds;
}

export function proxiedImage(url: string | null | undefined, mode: ProxyMode, absolute = false, nowMs = Date.now(), lifetimeSeconds = LIFETIME_SECONDS): string | null {
  if (!url) return null;
  if (isNonArticleImage(url)) return null;
  if (url.startsWith("data:")) return url;
  if (!/^https?:\/\//i.test(url)) return null;
  const exp = proxyExpiry(nowMs, lifetimeSeconds, (RESPONSIVE_MODES.avatar as readonly ProxyMode[]).includes(mode) ? AVATAR_WINDOW_SECONDS : WINDOW_SECONDS);
  return signedMediaUrl(url, mode, exp, absolute);
}

function signedMediaUrl(url: string, mode: string, exp: number, absolute: boolean): string {
  const path = `/api/img-proxy?u=${encodeURIComponent(url)}&mode=${mode}&exp=${exp}&sig=${signature(url, mode, exp)}`;
  return absolute ? `${config.siteUrl}${path}` : path;
}

/** Browser source candidates, each independently signed with the same expiry boundary. */
export function proxiedImageSet(url: string | null | undefined, kind: ResponsiveImageKind, absolute = false, nowMs = Date.now(), lifetimeSeconds = LIFETIME_SECONDS): string | null {
  if (!url || !/^https?:\/\//i.test(url) || isNonArticleImage(url)) return null;
  return RESPONSIVE_MODES[kind].map((mode) => `${proxiedImage(url, mode, absolute, nowMs, lifetimeSeconds)} ${IMAGE_WIDTHS[mode]}w`).join(", ");
}

export type VerifyResult = { ok: true; url: string; mode: string; avif: boolean } | { ok: false; reason: "missing" | "expired" | "bad-signature" | "bad-url" };

export function verifyProxyRequest(params: { u?: string; mode?: string; exp?: string; sig?: string }, nowMs = Date.now()): VerifyResult {
  const { u, mode, exp, sig } = params;
  if (!u || !mode || !exp || !sig) return { ok: false, reason: "missing" };
  if (!/^\d{9,11}$/.test(exp)) return { ok: false, reason: "missing" };
  if (Number(exp) * 1000 < nowMs) return { ok: false, reason: "expired" };
  if (!/^https?:\/\//i.test(u)) return { ok: false, reason: "bad-url" };
  const avif = mode.endsWith(AVIF_MODE_SUFFIX);
  const rendition = avif ? mode.slice(0, -AVIF_MODE_SUFFIX.length) : mode;
  if (rendition === X_VIDEO_MODE && !isXVideoUrl(u)) return { ok: false, reason: "bad-url" };
  if (avif && !(AVIF_MODES as readonly string[]).includes(rendition)) return { ok: false, reason: "bad-signature" };
  const given = Buffer.from(new RegExp(`^[0-9a-f]{${SIG_HEX}}$`, "i").test(sig) ? sig : "", "hex");
  const expected = Buffer.from(signature(u, rendition, exp), "hex");
  if (given.length === 0 || !timingSafeEqual(given, expected)) return { ok: false, reason: "bad-signature" };
  return { ok: true, url: u, mode: rendition, avif };
}

/**
 * Rewrites images, video posters and X MP4s in safe body HTML to signed proxy URLs. Feed readers keep
 * items for days, so full RSS asks for a longer signature than a page.
 */
export function proxyBodyImages(html: string, absolute = false, lifetimeSeconds = LIFETIME_SECONDS): string {
  const now = Date.now();
  const rewritten = html
    .replace(/<img\b([^>]*)>/gi, (tag: string, attrs: string, at: number, whole: string) => {
      const src = attrs.match(/\ssrc="([^"]+)"/i);
      if (!src) return tag;
      if (isNonArticleImage(src[1]!, attrs.match(/\bwidth="([^"]+)"/i)?.[1], attrs.match(/\bheight="([^"]+)"/i)?.[1])) return "";
      const decoded = src[1]!.replace(/&amp;/g, "&");
      const proxied = proxiedImage(decoded, "full", absolute, now, lifetimeSeconds);
      // Width descriptors change an image's natural CSS size. Only use them for a body image with
      // an explicit display width: unknown and small pictures must retain their intrinsic size.
      // RSS keeps its existing single signed full image.
      const width = Number(attrs.match(/\bwidth="(\d+)"/i)?.[1] ?? 0);
      const candidates = !absolute && width >= IMAGE_WIDTHS.thumb ? proxiedImageSet(decoded, "body", false, now, lifetimeSeconds) : null;
      // `sizes=auto` adds size containment in Chrome: stale publisher width/height metadata then
      // overrides the loaded image's real ratio. Let intrinsic dimensions win after loading.
      const sizes = ' sizes="(min-width: 1536px) 760px, (min-width: 1024px) calc(100vw - 524px), (min-width: 640px) 608px, calc(100vw - 32px)"';
      const responsive = candidates ? ` srcset="${candidates.replace(/&/g, "&amp;")}"${sizes}` : "";
      const source = proxied ? ` src="${proxied.replace(/&/g, "&amp;")}"${responsive} loading="lazy" decoding="async"` : "";
      const img = `<img${attrs.replace(src[0], source)}>`;
      if (!candidates || !proxied) return img;
      // Browsers without AVIF skip the source and load the img's own candidates. A publisher's own
      // picture (cleaning keeps it and drops its sources) takes the source: pictures do not nest.
      const avif = `<source type="image/avif" srcset="${avifCandidates(candidates).replace(/&/g, "&amp;")}"${sizes}>`;
      return /<picture\b[^>]*>\s*$/i.test(whole.slice(Math.max(0, at - 200), at)) ? `${avif}${img}` : `<picture class="contents">${avif}${img}</picture>`;
    })
    .replace(/<video\b([^>]*?)\sposter="([^"]+)"/gi, (_m, pre: string, src: string) => {
      const proxied = proxiedImage(src.replace(/&amp;/g, "&"), "thumb", absolute, now, lifetimeSeconds);
      return proxied ? `<video${pre} poster="${proxied.replace(/&/g, "&amp;")}"` : `<video${pre}`;
    });
  if (!/<video\b/i.test(rewritten)) return rewritten;
  const $ = cheerio.load(rewritten, null, false);
  const exp = proxyExpiry(now, lifetimeSeconds, WINDOW_SECONDS);
  // video.twimg.com is not directly reachable from mainland reader networks; the origin already
  // uses its guarded egress route to fetch X media.
  $("video[src], video > source[src]").each((_, el) => {
    const source = $(el);
    const url = source.attr("src")!;
    if (isXVideoUrl(url)) source.attr("src", signedMediaUrl(url, X_VIDEO_MODE, exp, absolute));
  });
  normalizeVideos($);
  return $.html();
}
