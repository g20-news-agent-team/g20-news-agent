// Story digest: rewritten incrementally as reports arrive; contradictions with earlier reporting are
// stated explicitly. Latest progress is bound to a current public report, not generated independently.
import { z } from "zod";
import { modelFor } from "../editorial/models.ts";
import { beijingDate, beijingTime } from "@aihot/contracts/time";
import { sql } from "../db.ts";
import { editorialPolicy } from "../modules.ts";
import { chatJson } from "../providers/llm.ts";
import { completeReceipt } from "../providers/receipts.ts";
import { publicSourceName } from "../publication/rules.ts";
import { digestFactEvidence, digestInputsHash, digestInputsHashMatches, digestReports, type DigestReport } from "../publication/story-evidence.ts";
import { promptText, promptVersion } from "../editorial/prompts.ts";

export const DIGEST_PROMPT_VERSION = promptVersion("story-digest");

export const DIGEST_SYSTEM = promptText("story-digest");

export const DigestSchema = z.object({
  title: z.string().max(120).catch(""),
  digest: z.string().min(10).max(2000),
});

/** Sampling of every digest request. */
export const DIGEST_SAMPLING = { temperature: 0.3, maxTokens: 1200 };

/** Oldest first; reports from the same moment keep the order digestReports returned them in. */
export const byReportTime = (a: { at: Date }, b: { at: Date }) => a.at.getTime() - b.at.getTime();

/**
 * The digest request's input, from one story's reports in byReportTime order. The evaluation
 * (scripts/eval-story-digests.ts) sends this, the system prompt and the sampling above as they are.
 */
export function buildStoryDigestInput(story: { title: string; digest: string | null }, reports: Array<Omit<DigestReport, "story_id" | "source_id">>, opts: { corrected: boolean; knownArticleIds?: string[] }) {
  const known = new Set(opts.knownArticleIds ?? []);
  const lines = reports.slice(-40).map((r) => `${opts.corrected || known.has(r.id) ? "" : "【新】"}报道 ${r.id}｜事实 ${r.fact_id}｜${beijingDate(r.at)} ${beijingTime(r.at)}｜${publicSourceName(r.source_name)}${r.first_party ? "（一手）" : ""}｜${r.title}｜${r.summary ?? ""}\n事实条件与来源证据：${JSON.stringify(digestFactEvidence(r))}`);
  return opts.corrected
    ? `事件当前标题：${story.title}\n\n报道内容或事实证据经过更正。请只依据下面这些报道的当前内容重写综述，不要沿用以前版本的说法。\n报道（按时间）：\n${lines.join("\n")}`
    : `事件当前标题：${story.title}\n${story.digest ? `上一版综述：${story.digest}\n` : ""}\n报道（按时间，标【新】的是上一版之后的新报道）：\n${lines.join("\n")}`;
}

/**
 * A story's digest from its current reports. `rewrite` (rewriteStoryDigest) writes it again from the reports
 * as they are now with the current prompt, as after a correction: a new wording otherwise reaches a story
 * only when its reports change.
 */
export async function composeStoryDigest(storyId: number, opts: { rewrite?: boolean } = {}): Promise<{ updated: boolean; version?: number }> {
  const [story] = await sql<{ id: number; title: string; digest: string | null; digest_version: number | null; version: number; origin: string }[]>`
    SELECT id, title, digest, digest_version, version, origin FROM stories WHERE id = ${storyId} AND merged_into IS NULL`;
  if (!story) return { updated: false };
  const reports = await digestReports(sql, [storyId]);
  if (reports.length === 0) {
    const cleared = await sql`UPDATE stories SET digest = NULL, digest_updated_at = NULL, digest_version = NULL, updated_at = now()
      WHERE id = ${storyId} AND version = ${story.version} AND merged_into IS NULL AND digest IS NOT NULL`;
    return { updated: cleared.count > 0 };
  }
  reports.sort(byReportTime);
  const ids = reports.map((r) => r.id).sort();
  // What this version is written from: the reports and what they currently say (corrections included).
  const inputsHash = digestInputsHash(reports);
  const [last] = await sql<{ article_ids: string[]; inputs_hash: string | null; digest: string; receipt_id: number | null }[]>`
    SELECT article_ids, inputs_hash, digest, receipt_id FROM story_digests WHERE story_id = ${storyId} ORDER BY version DESC LIMIT 1`;
  const sameReports = !!last && JSON.stringify([...last.article_ids].sort()) === JSON.stringify(ids);
  const sameInputs = !!last && digestInputsHashMatches(reports, last.inputs_hash, story.digest_version);
  if (!opts.rewrite && story.digest !== null && sameReports && sameInputs) return { updated: false };
  // Same reports, different content: an editor corrected one. A report gone from the story (withdrawn,
  // or regrouped elsewhere) likewise. Rewrite from the reports as they are now, without the previous
  // digest, so a corrected or withdrawn fact does not survive as "earlier reports said".
  const dropped = !!last && last.article_ids.some((id) => !ids.includes(id));
  const corrected = opts.rewrite === true || sameReports || dropped;
  const user = buildStoryDigestInput(story, reports, { corrected, knownArticleIds: last?.article_ids });
  const latest = reports[reports.length - 1]!.title;
  const fallbackDigest = reports
    .slice(-5)
    .map((r) => r.summary?.trim() || r.title.trim())
    .filter(Boolean)
    .join(" ")
    .slice(0, 2000) || latest;
  // A withdrawal clears the public projection but retains its history. Restoring exactly the same
  // evidence reuses that digest through the normal version/input checks, without another model call.
  const res = !opts.rewrite && sameInputs ? { data: { title: "", digest: last!.digest }, receiptId: last!.receipt_id } : await chatJson({
    model: await modelFor("digest"), purpose: "story_digest", subject: `story:${storyId}@${ids.length}`, promptVersion: DIGEST_PROMPT_VERSION,
    system: DIGEST_SYSTEM, user, schema: DigestSchema, ...DIGEST_SAMPLING,
  });
  const reviewed = editorialPolicy().reviewStoryDigest
    ? await editorialPolicy().reviewStoryDigest!({
        storyId,
        title: res.data.title || story.title,
        digest: res.data.digest,
        fallbackTitle: latest,
        fallbackDigest,
      })
    : null;
  const nextTitle = reviewed ? (res.data.title ? reviewed.title : (reviewed.title !== story.title ? reviewed.title : "")) : res.data.title;
  const nextDigest = reviewed ? reviewed.digest : res.data.digest;
  const allReceipts = [
    ...(res.receiptId !== null ? [res.receiptId] : []),
    ...(reviewed?.receiptIds ?? []),
  ];
  const version = story.version + 1;
  const updated = await sql.begin(async (tx) => {
    const [current] = await tx<{ version: number; merged_into: number | null }[]>`
      SELECT version, merged_into FROM stories WHERE id = ${storyId} FOR UPDATE`;
    // Report corrections, withdrawals and membership changes do not necessarily bump the story
    // version. Compare the same input identity again after the model returns.
    if (!current || current.version !== story.version || current.merged_into !== null || digestInputsHash(await digestReports(tx, [storyId])) !== inputsHash) {
      // A paid response remains reusable even when an editor or another digest won the race.
      for (const rid of new Set(allReceipts)) await completeReceipt(tx, rid);
      return false;
    }
    await tx`INSERT INTO story_digests (story_id, version, digest, receipt_id, article_ids, inputs_hash)
             VALUES (${storyId}, ${version}, ${nextDigest}, ${res.receiptId}, ${ids}, ${inputsHash})`;
    await tx`UPDATE stories SET digest = ${nextDigest}, digest_updated_at = now(), digest_version = ${version},
               title = CASE WHEN origin = 'manual' OR ${nextTitle} = '' THEN title ELSE ${nextTitle} END,
               version = ${version}, updated_at = now()
             WHERE id = ${storyId}`;
    for (const rid of new Set(allReceipts)) await completeReceipt(tx, rid);
    return true;
  });
  return updated ? { updated: true, version } : { updated: false };
}
