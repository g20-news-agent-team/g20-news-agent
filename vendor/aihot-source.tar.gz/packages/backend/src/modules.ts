// The backend's sockets for modules (modules/<name>/server.ts). The api and worker processes install the
// site's list when they start (site/modules/server.ts); the engine reads the sockets when it needs them and
// never imports a module, so it runs the same with none installed: the open-source edition, and the
// engine's own tests. Each socket names the engine file that reads it.
import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import type { WorkOptions } from "pg-boss";
import type { z } from "zod";
import type { MentionTarget } from "@aihot/contracts/mentions";
import type { Brand } from "@aihot/contracts/site";
import type { Db } from "./db.ts";
import type { QueueOptions } from "./jobs/queue.ts";
import type { Finding, FollowUp } from "./notify/feishu.ts";
import type { ContentPart } from "./providers/llm.ts";
import type { WantedText } from "./publication/english.ts";
import type { Topic, TopicMember } from "./publication/topics.ts";

/** A cron schedule (Asia/Shanghai), recorded in job_runs like the engine's (apps/worker/src/schedules.ts). */
export interface Scheduled {
  name: string;
  cron: string;
  run: () => Promise<unknown>;
  missed?: "skip" | "once";
  /** Read when the worker starts, after the modules are installed: false removes the schedule and its execution queue; run history remains. */
  when?: () => boolean;
}

/** A model step (editorial/models.ts); its default model comes from site/models.ts, else `default`. */
export interface ModelStep {
  label: string;
  env: string;
  /** Receipt purposes it produces (for the admin statistics). */
  purposes: string[];
  /** The step needs a model that reads images. */
  vision?: boolean;
}

/**
 * Something Agents can ask: an address under /api/v1/agent (routes/agent.ts) and an MCP tool with the
 * same answer (routes/mcp.ts), named in the guide (publication/agent.ts) and in llms.txt.
 */
export interface AgentAbility {
  /** Address under /api/v1/agent: "/status". */
  path: string;
  /** Named in the guide's first sentence, after the engine's abilities: "服务状态". */
  title: string;
  /** The guide's table row: what the user wants to know. */
  ask: string;
  /** The Markdown answer. */
  answer: () => Promise<string>;
  etagPrefix: string;
  cacheControl: string;
  mcp: {
    /** The tool name after the site's prefix: "get_status". */
    tool: string;
    /** What the server's instructions say it is for: "for service status". */
    use: string;
    description: string;
    input: z.ZodObject;
    /** The text (the same answer) and the structured content. */
    run: (args: Record<string, unknown>) => Promise<{ text: string; structured: Record<string, unknown> }>;
  };
}

/** Lines of /llms.txt (publication/llms.ts), each placed in its section. */
export interface LlmsLines {
  /** The public API list, after the engine's news endpoints. */
  api?: string[];
  /** Polling rhythm, a clause each, before the RSS one ("X 每 10 分钟读一次 …；"). */
  pace?: string[];
  /** The site's main pages, after the topics. */
  pages?: string[];
  /** What the topics section's opening sentence goes on to say about the topic pages, a clause each after "；". */
  topics?: string[];
  /** Sentences after the access section's opening one. */
  access?: string[];
  /** Its clients built on the Agent guide, by name: the guide's line says Agents without them read it, and that they read it too. */
  guideClients?: string[];
  /** Ways in of its own beside MCP, RSS and the API, a line each after the guide's. */
  ways?: string[];
}

/**
 * A job queue of its own, beside the engine's (jobs/queue.ts): created with its options on first use, worked
 * by the worker (workModuleQueues), and filled with `enqueueOn`, which types the data by the queue.
 */
export interface ModuleQueue<T = never> {
  /** "<module>.<what>". */
  name: string;
  /** Policy, retries and expiry (pg-boss createQueue). */
  options: QueueOptions;
  /** How the worker takes its jobs (pg-boss work). */
  worker: WorkOptions;
  /** All jobs taken together (batchSize); a failure retries the whole batch. */
  run: (data: T[]) => Promise<unknown>;
}

export function defineQueue<T>(queue: ModuleQueue<T>): ModuleQueue<T> {
  return queue;
}

export interface SitemapEntry {
  loc: string;
  /** Stable public-content identity for update notifications; never rendered into the sitemap. */
  revision?: string;
  lastmod?: Date | null;
  changefreq?: string;
  priority?: number;
  /** Set false while content needs translation. Only registered English pages are listed. */
  english?: boolean;
}

/**
 * What happened in the engine, for modules that act on it (`emit` below). A handler runs in the process
 * that made the change and, given one, inside its transaction.
 */
export interface EngineHooks {
  /**
   * An article's public content changed; a former event is included when its membership moved.
   * `reduced`: something public is now shown less, as publication judged it (`PublishResult`).
   */
  articleChanged: (change: { id: string; kind: "detail" | "body" | "content"; reduced?: boolean; reason: string; previousStoryIds?: number[] }, tx: Db) => Promise<void>;
  /** A source's articles were published again after changing its public metadata or permissions. */
  sourceRepublished: (change: { sourceId: string }) => Promise<void>;
  /** A report was published, or what one shows changed. */
  reportsChanged: (change: { reason: string }, tx: Db) => Promise<void>;
  /** The api answered a request. Never awaited and must not throw. */
  requestAnswered: (req: FastifyRequest, reply: FastifyReply, path: string) => void;
  /**
   * A public exit took a client's request: "rss" (routes/feeds.ts, a feed is sent), "mcp" (routes/mcp.ts,
   * past its host and origin checks) or a module's own. Never awaited and must not throw.
   */
  exitServed: (exit: string, req: FastifyRequest) => void;
}

/** A use of sources a module declares (ServerModule.sourceUses). */
export interface SourceUse {
  /** Its name in the admin's source list. */
  label: string;
  /** The longest it lets its sources wait between reads, in minutes; a faster pace of their own stays. */
  minutes?: number;
}

/** What a topic page asks a module's part of it (publication/topics.ts loadTopicPage). */
export interface TopicPageAsk {
  topic: Topic;
  page: number;
  /** The topic's members, newest first, as the topic index read them (it is kept a minute). */
  members: readonly TopicMember[];
  /** What its `index` computed with that index. */
  index: unknown;
  /** The page's time. */
  now: Date;
}

/** A reminder in a JSON answer, as its top-level `notice`. */
export interface JsonNotice {
  notice: object;
  /** It depends on what shared caches do not tell apart (the User-Agent): the answer is then kept in none. */
  private?: boolean;
}

/** A reminder for the person behind a JSON request; the first module with one gives it. */
export interface RequestNotices {
  json: (req: FastifyRequest) => JsonNotice | null;
}

export interface Previewer {
  name: string;
  actor: string;
}

export interface ServerModule {
  /** Its folder under modules/. */
  name: string;
  /** Who besides the engine's admin may open gray pages (ModulePage.gray) and read their data (admin/preview.ts). */
  preview?: (cookieHeader: string | undefined) => Promise<Previewer | null>;
  /** Admits only ModulePage.admin pages and their read-only data, not other /api/admin permissions. */
  admin?: (cookieHeader: string | undefined) => Promise<Previewer | null>;
  /** Sources whose selected articles keep independent cards/seats without changing admission or event identity (publication/rules.ts, scope.ts). */
  independentSelectedSources?: readonly string[];
  /** Another account of an independent source's author, by source id: its post gives way to the article on the same news (events/cards.ts). */
  independentSelectedEchoes?: Readonly<Record<string, string>>;
  /** Its HTTP routes, and hooks on the app such as what to flush when it closes, registered before the engine's v1 fallbacks (apps/api/src/app.ts). */
  http?: (app: FastifyInstance) => void;
  agent?: {
    abilities?: AgentAbility[];
    /** Questions answered by a web page's Markdown representation, without an MCP tool. */
    pages?: Array<{ ask: string; where: string }>;
    /** The guide's "请求" list (how to ask), after the engine's first entry. */
    requests?: string[];
  };
  llms?: () => Promise<LlmsLines> | LlmsLines;
  sitemap?: {
    /** The XML lists URLs and dates. Change notifications also need content revisions. */
    entries?: (withRevisions: boolean) => Promise<SitemapEntry[]>;
  };
  models?: Record<string, ModelStep>;
  /** Paid services it supplies, named in provider-access and budget alerts (operations/alerts.ts). */
  providers?: Record<string, { name: string; where: string; stops: string }>;
  /** Cron schedules (the worker). */
  schedules?: Scheduled[];
  /** What is wrong now, for the owner's alerts (operations/alerts.ts), after the engine's problems. */
  alerts?: (now: number) => Promise<Finding[]>;
  /** Its share of the daily retention run (operations/retention.ts): what it deleted or aggregated. */
  retention?: (now: Date) => Promise<Record<string, unknown>>;
  on?: Partial<EngineHooks>;
  /**
   * The Chinese its English answers show, for the worker to translate (editorial/english.ts; publication/english.ts
   * textsIn gathers them through the answers' own overlays). Called every few minutes: keep it cheap when nothing changed.
   */
  english?: () => Promise<WantedText[]>;
  /** Topic pages (publication/topics.ts). */
  topics?: {
    /**
     * Its part of a topic page, under its name in TopicPage.modules; its web module draws it. The page names
     * reports only as they are now, so withdrawals and corrections apply although the index is a minute old.
     */
    page?: {
      /** Computed from every member of the topic index when the index is read, and kept with it. */
      index?: (members: readonly TopicMember[], now: Date) => Promise<unknown>;
      /**
       * The members it may name, read again with the page, and its part from them as they are now: one no
       * longer selected is missing, `topics` is its current membership. Null when it has no part on the page.
       * Work the part out inside `part`, from `current`: what `read` works out from `ask.members` is up to a
       * minute old, so a withdrawn or corrected report would stay on the page until the index is read again.
       */
      read: (ask: TopicPageAsk) => { recheck: string[]; part: (current: ReadonlyMap<string, TopicMember>) => unknown } | null;
    };
    /** Company marks by topic slug, drawn over the engine's monograms. */
    marks?: () => Promise<Record<string, Brand>>;
  };
  /**
   * Source kinds it collects in its own way (admin/sources.ts), by kind: `resumed` runs in the transaction
   * that enables a paused source of that kind, before its row is written; `fetchNow` takes over the admin's
   * manual fetch, and what it returns is recorded in the audit trail.
   */
  sourceKinds?: Record<string, {
    resumed?: (sourceId: string, tx: Db) => Promise<void>;
    fetchNow?: (source: { id: string; config: Record<string, unknown> }) => Promise<Record<string, unknown>>;
  }>;
  /**
   * Uses of sources besides the news pipeline, by name (sources.uses, sources/uses.ts): the module reads the
   * articles of the sources that name one itself, so nothing is collected twice.
   */
  sourceUses?: Record<string, SourceUse>;
  /** Lines of the Monday source-health report (operations/reports.ts), after the source counts. */
  sourceHealth?: (now: number) => Promise<string[]>;
  /** Its pages that names in the site's own text link to, such as a model's page by the model's name (publication/mentions.ts). */
  mentions?: () => Promise<MentionTarget[]>;
  /** Job queues of its own (jobs/queue.ts). */
  queues?: ModuleQueue[];
  /** Follow-ups (level later), after the engine's (operations/alerts.ts). */
  followUps?: (now: number) => Promise<FollowUp[]>;
  /** Reminders for the person behind a JSON request (RequestNotices). */
  notices?: Partial<RequestNotices>;
  /** More keys a feedback sender is known by; a ban under any of them holds (operations/feedback.ts). */
  feedbackKeys?: (ip: string) => string[];
  /**
   * Its pages, by path ("/free-tokens"), whose reports it handles itself (operations/feedback.ts): they stay out
   * of the internal chat, and only their screenshots go to Feishu. It wakes whoever handles them (`alerts`).
   */
  feedbackPages?: readonly string[];
  /** Publication suitability review before analysis, translation or event digests are stored (editorial/analyze.ts, editorial/translate.ts, events/digest.ts). */
  editorial?: EditorialPolicy;
}

export interface EditorialFact {
  title: string;
  subject?: string | null;
  action?: string | null;
  object?: string | null;
  occurredAt?: string | null;
  evidence: string | null;
  conditions: Array<{ text: string; quote: string }>;
}

export interface EditorialLoadedImages {
  parts: ContentPart[];
  /** Images that could not be inspected (transient fetch failure, unsupported format or beyond review cap). */
  unverifiedCount: number;
}

export interface EditorialReviewInput {
  articleId: string;
  revision: number;
  attemptTag?: string;
  title: string;
  url: string;
  excerpt: string;
  bodyText: string;
  xPostText: string;
  xQuotedText: string;
  xArticleText?: string;
  imageCount?: number;
  loadImages?: () => Promise<EditorialLoadedImages>;
  relevance: "pass" | "block" | "unknown";
  selected: boolean;
  score: number | null;
  titleZh: string | null;
  summaryZh: string | null;
  reasonZh: string | null;
  fact: EditorialFact | null;
  contentRefused: boolean;
}

export interface EditorialReviewOutcome {
  relevance?: "pass" | "block" | "unknown";
  selected?: boolean;
  score?: number | null;
  titleZh?: string | null;
  summaryZh?: string | null;
  reasonZh?: string | null;
  fact?: EditorialFact | null;
  suppressOriginal?: boolean;
  withdrawn?: boolean;
  reused?: boolean;
  receiptIds?: number[];
  review?: Record<string, unknown>;
}

export interface EditorialTranslationReviewInput {
  subject: string;
  title: string;
  sourceText: string;
  translatedText: string;
  contentRefused?: boolean;
}

export interface EditorialStoryDigestReviewInput {
  storyId: number;
  title: string;
  digest: string;
  fallbackTitle?: string;
  fallbackDigest?: string;
}

export interface EditorialEventCopyInput {
  title: string;
  /** The member report's title and summary, to disambiguate a shorter event title. */
  reportContext?: string;
  fallbackTitle?: string | null;
  conditions?: string | null;
  subject?: string | null;
  action?: string | null;
  object?: string | null;
}

export interface EditorialEventCopyOutcome {
  title: string;
  conditions: string | null;
  subject: string | null;
  action: string | null;
  object: string | null;
}

export interface EditorialPolicy {
  /** Receipt purposes produced during analyzeArticle that should resume the article when an unknown receipt is released (jobs/content.ts). */
  analysisPurposes?: readonly string[];
  /** Reviews an analysed or provider-refused item before its analysis row is saved (editorial/analyze.ts). */
  reviewAnalysis?: (input: EditorialReviewInput) => Promise<EditorialReviewOutcome | null>;
  /** Reviews translated body or quote text before it is stored (editorial/translate.ts). */
  reviewTranslation?: (input: EditorialTranslationReviewInput) => Promise<{ allow: boolean; reason?: string; receiptIds?: number[] }>;
  /** Reviews a generated event title and digest before saving (events/digest.ts). */
  reviewStoryDigest?: (input: EditorialStoryDigestReviewInput) => Promise<{ title: string; digest: string; receiptIds?: number[] } | null>;
  /** Sanitizes stored fact and story copy when a report is grouped, revised or overridden. */
  sanitizeEventCopy?: (input: EditorialEventCopyInput) => EditorialEventCopyOutcome;
}

export function editorialPolicy(): EditorialPolicy {
  for (const m of installed) if (m.editorial) return m.editorial;
  return {};
}

export function defineServerModule(module: ServerModule): ServerModule {
  return module;
}

let installed: readonly ServerModule[] = [];

/** Called once by each process's entry point, and by a module's tests for that module. */
export function installModules(modules: readonly ServerModule[]): void {
  if (modules.filter((module) => module.preview).length > 1) throw new Error("Only one module may provide preview identity");
  installed = modules;
}

export function serverModules(): readonly ServerModule[] {
  return installed;
}

/** The first installed module's reminder for the person behind this request, at this exit. */
export function requestNotice<K extends keyof RequestNotices>(exit: K, ...args: Parameters<RequestNotices[K]>): ReturnType<RequestNotices[K]> | null {
  for (const m of installed) {
    const ask = m.notices?.[exit] as ((...a: Parameters<RequestNotices[K]>) => ReturnType<RequestNotices[K]>) | undefined;
    const notice = ask?.(...args);
    if (notice) return notice;
  }
  return null;
}

/** Tells every installed module that handles it, one after another. */
export async function emit<K extends Exclude<keyof EngineHooks, "requestAnswered" | "exitServed">>(hook: K, ...args: Parameters<EngineHooks[K]>): Promise<void> {
  for (const m of installed) {
    const handler = m.on?.[hook] as ((...a: Parameters<EngineHooks[K]>) => Promise<void>) | undefined;
    if (handler) await handler(...args);
  }
}
