// Feishu delivery uses the message app for internal feedback, operations alerts and image uploads.
// Content groups use custom bot webhooks, and so do
// alerts when FEISHU_ALERT_WEBHOOK_URL is set (they are plain text; feedback screenshots need the app).
// Alerts and feedback never go to content groups, and content never goes to internal chats. What the owner is
// told (sendAlert) goes first to Agent 自动化中台, which passes it on.
// Everything outward is off unless explicitly enabled (development and tests stay silent).
import { createHash } from "node:crypto";
import { readFile, unlink } from "node:fs/promises";
import path from "node:path";
import { beijingStamp } from "@aihot/contracts/time";
import { config, credential } from "../config.ts";
import { sql } from "../db.ts";

const API = "https://open.feishu.cn/open-apis";

export const feishuInternalEnabled = () => process.env.FEISHU_INTERNAL_ENABLED === "true";

let tokenCache: { token: string; expires: number } | null = null;

async function tenantToken(): Promise<string> {
  if (tokenCache && tokenCache.expires > Date.now() + 60_000) return tokenCache.token;
  const appId = credential("integrations", "FEISHU_APP_ID");
  const appSecret = credential("integrations", "FEISHU_APP_SECRET");
  if (!appId || !appSecret) throw new Error("Feishu message app is not configured");
  const res = await fetch(`${API}/auth/v3/tenant_access_token/internal`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ app_id: appId, app_secret: appSecret }),
    signal: AbortSignal.timeout(15_000),
  });
  const json = (await res.json()) as { code: number; tenant_access_token?: string; expire?: number; msg?: string };
  if (json.code !== 0 || !json.tenant_access_token) throw new Error(`feishu token: ${json.msg}`);
  tokenCache = { token: json.tenant_access_token, expires: Date.now() + (json.expire ?? 3600) * 1000 };
  return tokenCache.token;
}

/** Feishu's answers that the picture itself is unacceptable (bad image, too large, empty): trying again cannot help. */
const IMAGE_REFUSED = new Set([234001, 234006, 234010, 234011]);

class ImageRefusedError extends Error {}

async function uploadImage(data: Buffer, filename: string): Promise<string> {
  const form = new FormData();
  form.set("image_type", "message");
  form.set("image", new Blob([new Uint8Array(data)]), filename);
  const res = await fetch(`${API}/im/v1/images`, { method: "POST", headers: { authorization: `Bearer ${await tenantToken()}` }, body: form, signal: AbortSignal.timeout(30_000) });
  const json = (await res.json()) as { code: number; data?: { image_key: string }; msg?: string };
  if (IMAGE_REFUSED.has(json.code)) throw new ImageRefusedError(`feishu upload: ${json.msg}`);
  if (json.code !== 0 || !json.data) throw new Error(`feishu upload: ${json.msg}`);
  return json.data.image_key;
}

/** A picture this app uploaded, read back by its key (Feishu gives an app only its own uploads). */
export async function downloadImage(imageKey: string): Promise<Buffer> {
  const res = await fetch(`${API}/im/v1/images/${encodeURIComponent(imageKey)}`, { headers: { authorization: `Bearer ${await tenantToken()}` }, signal: AbortSignal.timeout(30_000) });
  if (!res.ok) throw new Error(`feishu image: HTTP ${res.status} ${(await res.text()).slice(0, 200)}`);
  return Buffer.from(await res.arrayBuffer());
}

async function sendToChat(chatId: string, msgType: "text" | "post" | "interactive", content: unknown): Promise<string> {
  const res = await fetch(`${API}/im/v1/messages?receive_id_type=chat_id`, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${await tenantToken()}` },
    body: JSON.stringify({ receive_id: chatId, msg_type: msgType, content: JSON.stringify(content) }),
    signal: AbortSignal.timeout(20_000),
  });
  const json = (await res.json()) as { code: number; data?: { message_id: string }; msg?: string };
  if (json.code !== 0) throw new Error(`feishu send: ${json.msg}`);
  return json.data?.message_id ?? "";
}

// Operations alerts
// Read by the site owner, not an engineer (operations/alerts.ts): what readers see, whether it heals,
// and what the owner must do.

/** How urgent: readers affected now, money or the owner's hands today, or a follow-up that can wait. */
export type Level = "now" | "today" | "later";

interface FindingFields {
  key: string;
  level: Level;
  /** Plain words: no queue, unit or table names. */
  title: string;
  /** What readers see, or what it costs. */
  impact?: string;
  /** Whether it heals by itself. */
  heals?: string;
  /** What has to be done. */
  action?: string;
  /** Facts for whoever looks into it: the 09:00 digest lists them, an alert to the owner never carries them. */
  detail?: string;
  /** When the problem began, when known; otherwise when it was first seen. */
  since?: Date;
  /** New evidence after a dated closure reopens a source follow-up under the same key. */
  observedAt?: Date;
  /**
   * The owner hears of it at once even while an agent takes the alerts (operations/alerts.ts): only the owner
   * can act (paying, renewing, a device beside them), or what would act has stopped (the whole site, the
   * machine the agent runs on, the channel to the agent). "only": nothing in it is the agent's to do (a
   * top-up), so the agent is not woken for it. "private" also limits delivery to the owner's private chat.
   */
  owner?: true | "only" | "private";
  /**
   * The agent is the one to act: whenever the owner is messaged about it, the agent is woken first and the
   * message says so instead of asking him to pass it on (operations/alerts.ts).
   */
  agentFirst?: true;
  /**
   * Do not message the owner, including when it clears or when a follow-up is derived from the handoff.
   * On the incident itself it is now or today and is woken: a later finding is not. One such key is one
   * occurrence, so the wake's event id is the key, not a time. The derived follow-up keeps the flag and
   * stays on the ops list only.
   */
  agentOnly?: true;
}

/**
 * An agent-only finding names what kind of work it is (`alert.<kind>`); which rule of the hub takes that kind, and when,
 * is the hub's to say. No default: a new kind must not fall silently to another kind's handling.
 */
export type Finding = FindingFields & ({ agentOnly?: undefined; agentType?: undefined } | { agentOnly: true; agentType: `alert.${string}` });

export type FollowUp = Finding & { level: "later" };

const MARK: Record<Exclude<Level, "later">, string> = { now: "🔴", today: "🟠" };


export function duration(ms: number): string {
  const min = Math.max(1, Math.round(ms / 60_000));
  if (min < 60) return `${min} 分钟`;
  if (min < 48 * 60) return `${Math.floor(min / 60)} 小时${min % 60 ? ` ${min % 60} 分钟` : ""}`;
  return `${Math.floor(min / 1440)} 天`;
}

/** The message for an open problem: first notice or a repeat. */
export function formatAlert(f: Finding, since: Date, now: number, repeat = false): { title: string; lines: string[] } {
  const level = f.level === "later" ? "today" : f.level;
  const lasting = now - since.getTime() >= 60_000 ? `（已持续 ${duration(now - since.getTime())}）` : "";
  const lines = [f.impact && `影响：${f.impact}`, f.heals && `会自己好吗：${f.heals}`, f.action && `你需要：${f.action}`];
  return { title: `${MARK[level]} ${repeat ? "仍未恢复：" : ""}${f.title}${lasting}`, lines: lines.filter((l): l is string => !!l) };
}

/** A problem handed to the agent that keeps coming back: told once, with no recovery to follow. */
export function formatReturn(f: Finding, count: number): { title: string; lines: string[] } {
  const level = f.level === "later" ? "today" : f.level;
  const lines = [f.impact && `影响：${f.impact}`, "会自己好吗：每次都交给 AI 处理好了，但又出现，说明还没修到根上", "你需要：让 AI 查清它为什么反复出现，不只处理这一次"];
  return { title: `${MARK[level]} 反复出现：${f.title}（一天内第 ${count} 次）`, lines: lines.filter((l): l is string => !!l) };
}

export function formatRecovery(title: string, since: Date, now: number): { title: string; lines: string[] } {
  return { title: `✅ 已恢复：${title}`, lines: [`持续 ${duration(now - since.getTime())}（${beijingStamp(since)} 起）`] };
}

/**
 * The hub sends the notification to the owner. A private message ID lets the caller retry exactly
 * that notice through the hub. Other alerts use the existing group channel if the hub is unavailable.
 */
export async function sendAlert(title: string, lines: string[], privateMessageId?: string): Promise<"sent" | "disabled" | "pending"> {
  // Production needs no label; any other environment that has sending on says which one it is.
  const text = `${config.environmentName === "production" ? "" : `【${config.environmentName}】`}${title}\n${lines.join("\n")}`;
  if (!feishuInternalEnabled()) {
    console.log(JSON.stringify({ level: "warn", msg: "alert (not sent: FEISHU_INTERNAL_ENABLED is off)", title, lines }));
    return "disabled";
  }
  const rest = await toldThroughHub(webhookPieces(text), privateMessageId);
  if (!rest.length) return "sent";
  if (privateMessageId) return "pending";
  const webhook = credential("integrations", "FEISHU_ALERT_WEBHOOK_URL");
  if (webhook) {
    for (const piece of rest) {
      const result = await webhookTurn(() => sendWebhook(webhook, { msg_type: "text", content: { text: piece } }));
      if (result.status !== "sent") throw new Error(`feishu alert webhook ${result.status}: ${result.body}`);
    }
    return "sent";
  }
  const chat = credential("integrations", "FEISHU_ALERT_CHAT_ID") ?? credential("integrations", "FEISHU_INTERNAL_CHAT_ID");
  if (!chat) return "disabled";
  await sendToChat(chat, "text", { text: rest.join("") });
  return "sent";
}

/**
 * Hands the pieces to the hub's /tell with the source key, each under its own message key.
 * Returns the unsent pieces so the caller can apply the alert's delivery policy.
 */
async function toldThroughHub(pieces: string[], messageId?: string): Promise<string[]> {
  const hub = credential("integrations", "WEBHOOK_HUB_URL");
  const key = credential("integrations", "WEBHOOK_HUB_KEY");
  if (!hub || !key) return pieces;
  const id = messageId ?? `alert-${Date.now()}-${createHash("sha256").update(pieces.join("")).digest("hex").slice(0, 12)}`;
  for (const [i, piece] of pieces.entries()) {
    try {
      const res = await fetch(new URL("/tell", hub), {
        method: "POST", redirect: "error", headers: { authorization: `Bearer ${key}`, "content-type": "application/json" },
        body: JSON.stringify({ key: `${id}-${i}`, text: piece }), signal: AbortSignal.timeout(15_000),
      });
      if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
    } catch (error) {
      console.error(JSON.stringify({ level: "warn", msg: "alert not taken by the hub", taken: i, error: String(error) }));
      return pieces.slice(i);
    }
  }
  return [];
}

// A custom bot takes at most 5 requests a second, 100 a minute and 20 KB a request (Feishu's custom bot
// guide); the app's text messages took 150 KB. One check can send many alerts, and the digests are long.
const WEBHOOK_GAP_MS = 600;
const WEBHOOK_TEXT_BYTES = 18_000;
let webhookQueue: Promise<void> = Promise.resolve();
let webhookLast = -Infinity;

/**
 * One request at a time, sent the gap after the last one was answered or failed: Feishu got that one before
 * it answered, so however late a timer, a request or an answer, it never gets two closer than the gap.
 */
function webhookTurn<T>(send: () => Promise<T>): Promise<T> {
  const turn = webhookQueue.then(async () => {
    // Checked again after the timer, which can fire a millisecond early by this clock.
    let wait: number;
    while ((wait = webhookLast + WEBHOOK_GAP_MS - performance.now()) > 0) await new Promise((resolve) => setTimeout(resolve, wait));
    try {
      return await send();
    } finally {
      webhookLast = performance.now();
    }
  });
  webhookQueue = turn.then(() => undefined, () => undefined);
  return turn;
}

/** Bytes the text takes in the request body, where quotes, backslashes and line breaks are escaped. */
const jsonBytes = (text: string) => Buffer.byteLength(JSON.stringify(text)) - 2;

/** The text in pieces that fit a request, cut after a line where one fits; joined they are the text. */
function webhookPieces(text: string): string[] {
  const pieces: string[] = [];
  let rest = text;
  while (jsonBytes(rest) > WEBHOOK_TEXT_BYTES) {
    let end = 0;
    let bytes = 0;
    for (const ch of rest) {
      bytes += jsonBytes(ch);
      if (bytes > WEBHOOK_TEXT_BYTES) break;
      end += ch.length;
    }
    const line = rest.lastIndexOf("\n", end - 1);
    if (line > 0) end = line + 1;
    pieces.push(rest.slice(0, end));
    rest = rest.slice(end);
  }
  pieces.push(rest);
  return pieces;
}

/** A screenshot that still cannot be uploaded this long after the feedback is given up: the text goes without it. */
const SCREENSHOT_GIVE_UP_MS = 24 * 3600_000;

/**
 * The screenshot to attach, uploaded now or on an earlier try. Only the Feishu image key is kept (privacy
 * notice): the local file is removed once uploaded, or once the upload is given up.
 */
async function screenshotFor(fb: { id: number; screenshot_key: string | null; created_at: Date }): Promise<{ imageKey: string | null; note: string | null }> {
  const key = fb.screenshot_key;
  if (key?.startsWith("feishu:")) return { imageKey: key.slice("feishu:".length), note: null };
  if (key === "gone:upload") return { imageKey: null, note: "（截图未能上传，已删除）" };
  if (key === "gone:missing") return { imageKey: null, note: "（截图文件已不存在）" };
  if (!key?.startsWith("local:")) return { imageKey: null, note: null };
  const file = path.join(config.dataDir, "feedback-screenshots", key.slice("local:".length));
  const data = await readFile(file).catch(() => null);
  if (!data) {
    await sql`UPDATE feedback SET screenshot_key = 'gone:missing' WHERE id = ${fb.id}`;
    return { imageKey: null, note: "（截图文件已不存在）" };
  }
  try {
    const imageKey = await uploadImage(data, path.basename(file));
    await sql`UPDATE feedback SET screenshot_key = ${`feishu:${imageKey}`} WHERE id = ${fb.id}`;
    await unlink(file).catch(() => {});
    return { imageKey, note: null };
  } catch (error) {
    // The forwarding sweep tries again; after a day, or at once when Feishu refuses the picture itself,
    // the text goes without it.
    if (!(error instanceof ImageRefusedError) && Date.now() - fb.created_at.getTime() < SCREENSHOT_GIVE_UP_MS) throw error;
    await sql`UPDATE feedback SET screenshot_key = 'gone:upload' WHERE id = ${fb.id}`;
    await unlink(file).catch(() => {});
    return { imageKey: null, note: "（截图未能上传，已删除）" };
  }
}

/**
 * Forwards one feedback to the internal chat, with its screenshot. Until that succeeds the feedback keeps
 * the reason in forward_error, and the forwarding sweep (operations/feedback.ts) tries it again.
 * `tell` false: the chat is not told, and only the screenshot goes to Feishu ("kept").
 */
export async function forwardFeedbackToFeishu(id: number, tell = true): Promise<"sent" | "kept" | "disabled"> {
  if (!feishuInternalEnabled()) return "disabled";
  const chat = credential("integrations", "FEISHU_INTERNAL_CHAT_ID");
  if (!chat) return "disabled";
  const [fb] = await sql<{ id: number; content: string; email: string | null; note: string | null; page_url: string | null; screenshot_key: string | null; created_at: Date }[]>`
    SELECT id, content, email, note, page_url, screenshot_key, created_at FROM feedback WHERE id = ${id} AND forwarded_at IS NULL`;
  if (!fb) return "disabled";
  try {
    const shot = await screenshotFor(fb);
    if (!tell) {
      await sql`UPDATE feedback SET forward_error = NULL WHERE id = ${id}`;
      return "kept";
    }
    const paragraphs: unknown[][] = [
      [{ tag: "text", text: fb.content }],
      [{ tag: "text", text: `页面：${fb.page_url ?? "—"}` }],
      [{ tag: "text", text: `邮箱：${fb.email ?? "（未留）"}` }],
    ];
    if (fb.note) paragraphs.push([{ tag: "text", text: fb.note }]);
    if (shot.imageKey) paragraphs.push([{ tag: "img", image_key: shot.imageKey }]);
    else if (shot.note) paragraphs.push([{ tag: "text", text: shot.note }]);
    await sendToChat(chat, "post", { zh_cn: { title: `反馈 #${fb.id}`, content: paragraphs } });
    await sql`UPDATE feedback SET forwarded_at = now(), forward_error = NULL WHERE id = ${id}`;
    return "sent";
  } catch (error) {
    await sql`UPDATE feedback SET forward_error = ${String(error instanceof Error ? error.message : error).slice(0, 300)} WHERE id = ${id}`;
    throw error;
  }
}

/** Custom-bot webhook for content groups (selected cards and other pushes). */
export function postWebhook(url: string, card: unknown): Promise<{ status: "sent" | "failed" | "unknown"; body: string }> {
  return sendWebhook(url, { msg_type: "interactive", card });
}

/**
 * POST a custom-bot message and read the acknowledgement. `code` picks the bot's result code (0 = accepted)
 * from its JSON answer; the other bots (notify/dingtalk.ts) differ only there.
 */
export async function sendWebhook(
  url: string, message: unknown,
  code: (json: Record<string, unknown> | null) => unknown = (json) => json?.code ?? json?.StatusCode,
): Promise<{ status: "sent" | "failed" | "unknown"; body: string }> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(message),
    signal: AbortSignal.timeout(15_000),
  });
  const body = await res.text();
  // A successful HTTP transport is not an acknowledgement: proxies can return HTML or empty JSON.
  let status: "sent" | "failed" | "unknown" = res.status >= 400 && res.status < 500 ? "failed" : "unknown";
  try {
    const result = code(JSON.parse(body) as Record<string, unknown> | null);
    if (res.ok && typeof result === "number") status = result === 0 ? "sent" : "failed";
  } catch {
    // non-JSON body
  }
  return { status, body: body.slice(0, 500) };
}
