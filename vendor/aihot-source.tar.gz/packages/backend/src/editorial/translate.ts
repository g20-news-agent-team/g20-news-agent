// Full-text Chinese translations: made by the worker after an item
// is selected, for sources whose full text may be shown on the site; a page read never translates.
// Bodies are translated block by block (paragraphs, headings, list items, captions, table cells) so the
// sanitised structure stays as it is. Inside a block, images and inline code never reach the model
// (placeholders) and links keep only their text and an id; a block whose answer loses or repeats any of
// them is asked once more, closer to the original wording (rewording is what drops links), then kept in
// the original. Each batch is a receipt, so a re-run reuses
// answers already paid for. A translation missing any block is stored as incomplete, never as whole.
// The post a selected X post quotes is translated too (once per quoted post, shared by every quote).
import * as cheerio from "cheerio";
import type { AnyNode, Element } from "domhandler";
import { z } from "zod";
import { sql } from "../db.ts";
import { sanitizeBody, textToHtml } from "../content/sanitize.ts";
import { htmlAltText, rebaseTranslation } from "../content/presentation.ts";
import { chatJson } from "../providers/llm.ts";
import { completeReceipt, failureKind, providerContentRefused, ProviderRejectedError, rejectReceivedResponse } from "../providers/receipts.ts";
import { collapseWhitespace, htmlBlockText, isChineseText, mergeDistinctText } from "../lib/text.ts";
import { isEmptyOrLinkOnly, xArticleBody } from "../content/posts.ts";
import { sha256 } from "../lib/ids.ts";
import { modelFor } from "./models.ts";
import { shutdownSignal } from "../jobs/queue.ts";
import { promptText, promptVersion } from "./prompts.ts";
import { editorialPolicy, emit } from "../modules.ts";
import { republishTx } from "../publication/publish.ts";

export const TRANSLATE_PROMPT_VERSION = promptVersion("translate-body", "translate-body-retry", "translate-post");
const BATCH_CHARS = 3500;
/** Longer bodies (as sent to the model) get their first part translated and are marked incomplete. */
const MAX_CHARS = 60_000;
/** X posts shorter than this carry their meaning in the Chinese title and summary. */
const X_MIN_CHARS = 60;

const BLOCK = new Set(["p", "h2", "h3", "h4", "h5", "li", "blockquote", "figcaption", "td", "th", "dt", "dd", "caption"]);
const CONTAINER = /^(p|h[2-5]|li|blockquote|figcaption|td|th|dt|dd|caption|ul|ol|table|pre|figure|div)$/;

const Output = z.object({ t: z.array(z.string()) });

/**
 * A failure that ends the run without counting against the item: model calls switched off, a full
 * budget, an account refusal, the same request in flight, or the provider down for now.
 * The next scheduled run can try again without consuming an item attempt.
 */
const endsRun = (error: unknown) => ["off", "budget", "busy", "outage"].includes(failureKind(error))
  || (error instanceof ProviderRejectedError && error.accessRefused);

const SYSTEM_BODY = promptText("translate-body");

const SYSTEM_RETRY = promptText("translate-body-retry");

const SYSTEM_POST = promptText("translate-post");

export interface TranslateResult {
  articleId: string;
  status: "translated" | "partial" | "skipped" | "failed";
  /** The article revision this result is about: the one read and translated, not a later one. */
  revision?: number;
  segments?: number;
  reason?: string;
}

/** Leaf text blocks of a sanitised body, in document order, skipping code. */
export function segmentsOf($: cheerio.CheerioAPI): Element[] {
  const out: Element[] = [];
  const visit = (nodes: AnyNode[]) => {
    for (const node of nodes) {
      if (node.type !== "tag") continue;
      const el = node as Element;
      if (el.name === "pre" || el.name === "code") continue;
      const hasBlockChild = el.children.some((c) => c.type === "tag" && CONTAINER.test((c as Element).name));
      if (BLOCK.has(el.name) && !hasBlockChild) {
        if (/\p{L}/u.test($(el).text())) out.push(el);
        continue;
      }
      visit(el.children);
    }
  };
  visit($.root().children().toArray());
  return out;
}

interface BatchTranslation {
  translated: string[] | null;
  receiptId: number;
}

async function translateBatch(articleId: string, revision: number, index: number, parts: string[], system: string, attemptTag?: string): Promise<BatchTranslation> {
  const model = await modelFor("translate");
  shutdownSignal.signal.throwIfAborted();
  const res = await chatJson({
    model,
    purpose: "translate_body",
    subject: `article:${articleId}@${revision}#${index}`,
    promptVersion: TRANSLATE_PROMPT_VERSION,
    system,
    user: JSON.stringify({ segments: parts }),
    schema: Output,
    temperature: 0.2,
    maxTokens: Math.min(8000, Math.ceil(parts.join("").length * 1.2) + 400),
    timeoutMs: 180_000,
    attemptTag,
  });
  return { translated: res.data.t.length === parts.length ? res.data.t : null, receiptId: res.receiptId };
}

/** Translates batches, retaining every paid receipt used before the final body is committed. */
async function translateAll(
  articleId: string, revision: number, parts: string[], system: string, attemptTag?: string,
): Promise<{ translations: Array<string | null>; receiptIds: number[] }> {
  const out: Array<string | null> = new Array(parts.length).fill(null);
  const receiptIds: number[] = [];
  let start = 0;
  let index = 0;
  while (start < parts.length) {
    let end = start;
    let chars = 0;
    while (end < parts.length && (end === start || chars + parts[end]!.length <= BATCH_CHARS)) chars += parts[end++]!.length;
    const batch = parts.slice(start, end);
    const first = await translateBatch(articleId, revision, index++, batch, system, attemptTag);
    receiptIds.push(first.receiptId);
    let done = first.translated;
    if (!done && batch.length > 1) {
      const mid = Math.ceil(batch.length / 2);
      const left = await translateBatch(articleId, revision, index++, batch.slice(0, mid), system, attemptTag);
      const right = await translateBatch(articleId, revision, index++, batch.slice(mid), system, attemptTag);
      receiptIds.push(left.receiptId, right.receiptId);
      done = left.translated && right.translated ? [...left.translated, ...right.translated] : null;
    }
    if (done) done.forEach((t, i) => (out[start + i] = t));
    start = end;
  }
  return { translations: out, receiptIds };
}

/** A block as the model sees it: media and inline code as ⟦n⟧, links as <a id="Ln"> with their attributes kept here. */
interface Shielded {
  html: string;
  tokens: string[];
  links: Array<Record<string, string>>;
}

export function shield(inner: string): Shielded {
  const $ = cheerio.load(inner, null, false);
  const tokens: string[] = [];
  for (const node of $("picture, video, img, code").toArray()) {
    if ($(node).parents("picture, video, code").length) continue;
    tokens.push($.html(node));
    $(node).replaceWith(`⟦${tokens.length - 1}⟧`);
  }
  const links: Shielded["links"] = [];
  $("a").each((i, a) => {
    links.push({ ...(a as Element).attribs });
    (a as Element).attribs = { id: `L${i}` };
  });
  return { html: $.html(), tokens, links };
}

/** The translated block with its media, code and links put back; null when the answer lost or repeated any. */
export function unshield(translated: string, s: Shielded): string | null {
  const counts = new Map<number, number>();
  for (const m of translated.matchAll(/⟦(\d+)⟧/g)) counts.set(Number(m[1]), (counts.get(Number(m[1])) ?? 0) + 1);
  if (counts.size !== s.tokens.length || s.tokens.some((_t, i) => counts.get(i) !== 1)) return null;
  const $ = cheerio.load(translated, null, false);
  const seen = new Set<number>();
  let intact = true;
  $("a").each((_i, a) => {
    const n = /^L(\d+)$/.exec((a as Element).attribs.id ?? "")?.[1];
    const attribs = n === undefined ? undefined : s.links[Number(n)];
    if (!attribs || seen.has(Number(n))) intact = false;
    else {
      seen.add(Number(n));
      (a as Element).attribs = attribs;
    }
  });
  if (!intact || seen.size !== s.links.length) return null;
  return $.html().replace(/⟦(\d+)⟧/g, (_m, n: string) => s.tokens[Number(n)]!);
}

async function suppressFromTranslation(articleId: string, revision: number, receiptIds: number[], reason: string): Promise<boolean> {
  return sql.begin(async (tx) => {
    const [current] = await tx<{ revision: number }[]>`SELECT revision FROM articles WHERE id = ${articleId} FOR UPDATE`;
    let suppressed = false;
    if (current && current.revision === revision) {
      const updated = await tx<{ id: number }[]>`
        UPDATE analyses SET output = coalesce(output, '{}'::jsonb) || jsonb_build_object('suppressOriginal', true, 'translationReview', ${reason}::text)
        WHERE id = (SELECT id FROM analyses WHERE article_id = ${articleId} AND input_revision = ${revision} ORDER BY id DESC LIMIT 1)
        RETURNING id`;
      if (updated.length > 0) {
        await republishTx(tx, articleId);
        suppressed = true;
      }
    }
    for (const id of new Set(receiptIds)) await completeReceipt(tx, id);
    return suppressed;
  });
}

export async function translateArticle(articleId: string, expectedRevision?: number): Promise<TranslateResult> {
  const [row] = await sql<{ revision: number; channel: string; language: string | null; body_html: string | null; body_text: string | null; x_post: { text?: string } | null; x_article: { title?: string; text?: string; html?: string } | null; title: string; selected: boolean; body_mode: string; visibility: string }[]>`
    SELECT a.revision, p.channel, a.language, a.body_html, a.body_text, a.x_post, a.x_article, p.title, p.selected, p.body_mode, p.visibility
    FROM publications p JOIN articles a ON a.id = p.article_id WHERE p.article_id = ${articleId}
      AND (${expectedRevision ?? null}::int IS NULL OR a.revision = ${expectedRevision ?? null})`;
  if (!row) return { articleId, revision: expectedRevision, status: "skipped", reason: "not published at the requested revision" };
  const result = (r: Omit<TranslateResult, "articleId" | "revision">): TranslateResult => ({ articleId, revision: row.revision, ...r });
  // No answer could be used: each is rejected, so the next attempt pays for fresh ones instead of reusing them.
  const unusable = async (receiptIds: number[], reason: string) => {
    for (const id of new Set(receiptIds)) await rejectReceivedResponse(id, `unusable translation: ${reason}`);
    return result({ status: "failed", reason });
  };
  if (!row.selected || row.visibility !== "public" || row.body_mode !== "full") {
    return result({ status: "skipped", reason: "not a selected full-text item" });
  }
  const reviewer = editorialPolicy().reviewTranslation;

  // A post with a saved long article reads as an article (publication/detail.ts), so it is translated as an
  // article's body is: the post's own words and the article as laid out (xArticleBody), never the post's
  // introduction alone, which would stand in for the whole article.
  const article = row.channel === "x" && (row.x_article?.text || row.x_article?.html) ? row.x_article : null;
  if (article && !article.html) return result({ status: "skipped", reason: "saved long article without its layout" });
  if (row.channel === "x" && !article) {
    const text = String(row.x_post?.text ?? row.body_text ?? "").trim();
    if (isEmptyOrLinkOnly(text)) return result({ status: "skipped", reason: "no text to translate" });
    const meaningful = collapseWhitespace(text.replace(/https?:\/\/\S+/g, ""));
    if (isChineseText(text, row.language)) return result({ status: "skipped", reason: "already Chinese" });
    if (meaningful.length < X_MIN_CHARS) return result({ status: "skipped", reason: "short post" });
    let translated;
    try {
      translated = await translateAll(articleId, row.revision, [text], SYSTEM_POST);
    } catch (error) {
      if (reviewer && providerContentRefused(error)) {
        const verdict = await reviewer({ subject: `article:${articleId}@${row.revision}`, title: row.title, sourceText: text, translatedText: "", contentRefused: true });
        if (!verdict.allow) {
          const suppressed = await suppressFromTranslation(articleId, row.revision, verdict.receiptIds ?? [], verdict.reason ?? "translation refused");
          return result({ status: "skipped", reason: suppressed ? (verdict.reason ?? "original suppressed") : "stale revision" });
        }
      }
      throw error;
    }
    const [t] = translated.translations;
    if (!t) return unusable(translated.receiptIds, "translation did not line up");
    if (reviewer) {
      const verdict = await reviewer({ subject: `article:${articleId}@${row.revision}`, title: row.title, sourceText: text, translatedText: t });
      const allReceipts = [...translated.receiptIds, ...(verdict.receiptIds ?? [])];
      if (!verdict.allow) {
        const suppressed = await suppressFromTranslation(articleId, row.revision, allReceipts, verdict.reason ?? "original suppressed");
        return result({ status: "skipped", reason: suppressed ? (verdict.reason ?? "original suppressed") : "stale revision" });
      }
      await store(articleId, row.revision, row.title, textToHtml(t), t, true, allReceipts);
      return result({ status: "translated", segments: 1 });
    }
    await store(articleId, row.revision, row.title, textToHtml(t), t, true, translated.receiptIds);
    return result({ status: "translated", segments: 1 });
  }

  const source = article ? xArticleBody(String(row.x_post?.text ?? ""), article.html!) : row.body_html;
  if (!source) return result({ status: "skipped", reason: "no foreign-language body" });
  const renderedText = mergeDistinctText(htmlBlockText(source), htmlAltText(source));
  const sourceText = article
    ? mergeDistinctText(row.x_post?.text, article.title, article.text, renderedText)
    : mergeDistinctText(row.body_text, renderedText);
  const languageBasis = (article ? article.text : row.body_text) || sourceText;
  if (isChineseText(languageBasis, row.language)) return result({ status: "skipped", reason: "no foreign-language body" });
  const $ = cheerio.load(source, null, false);
  const blocks = segmentsOf($);
  if (!blocks.length) return result({ status: "skipped", reason: "no translatable text" });
  // Beyond the cap, only the leading blocks are translated; the rest keep the original text. The cap
  // counts what the model is sent: link addresses and media stay behind their placeholders.
  let budget = MAX_CHARS;
  const chosen: Element[] = [];
  const shielded: Shielded[] = [];
  for (const el of blocks) {
    const block = shield($(el).html() ?? "");
    if (block.html.length > budget) break;
    budget -= block.html.length;
    chosen.push(el);
    shielded.push(block);
  }
  // No model request was made when even the first block exceeds the text cap.
  if (!chosen.length) return result({ status: "skipped", reason: "no batch translated" });
  const restore = (answers: Array<string | null>) => answers.map((t, i) => (t === null ? null : unshield(t, shielded[i]!)));
  const receiptIds: number[] = [];
  let translations: Array<string | null>;
  try {
    const first = await translateAll(articleId, row.revision, shielded.map((b) => b.html), SYSTEM_BODY);
    receiptIds.push(...first.receiptIds);
    translations = restore(first.translations);
    // Blocks whose answer dropped a link or an image are asked once more, on their own receipt, with the retry prompt.
    const missing = translations.flatMap((t, i) => (t === null ? [i] : []));
    if (missing.length) {
      const again = await translateAll(articleId, row.revision, missing.map((i) => shielded[i]!.html), SYSTEM_RETRY, "retry");
      receiptIds.push(...again.receiptIds);
      missing.forEach((i, k) => (translations[i] = again.translations[k] ? unshield(again.translations[k]!, shielded[i]!) : null));
    }
  } catch (error) {
    if (reviewer && providerContentRefused(error)) {
      const verdict = await reviewer({ subject: `article:${articleId}@${row.revision}`, title: row.title, sourceText, translatedText: "", contentRefused: true });
      receiptIds.push(...(verdict.receiptIds ?? []));
      if (!verdict.allow) {
        const suppressed = await suppressFromTranslation(articleId, row.revision, receiptIds, verdict.reason ?? "translation refused");
        return result({ status: "skipped", reason: suppressed ? (verdict.reason ?? "original suppressed") : "stale revision" });
      }
    }
    throw error;
  }
  let done = 0;
  chosen.forEach((el, i) => {
    const t = translations[i];
    if (t) {
      $(el).html(t);
      done += 1;
    }
  });
  if (!done) return unusable(receiptIds, "no batch translated");
  const complete = done === blocks.length;
  const html = sanitizeBody($.html());
  const translatedText = cheerio.load(html, null, false).root().text().trim();
  if (reviewer) {
    const reviewTranslatedText = mergeDistinctText(htmlBlockText(html), translatedText);
    const verdict = await reviewer({ subject: `article:${articleId}@${row.revision}`, title: row.title, sourceText, translatedText: reviewTranslatedText });
    receiptIds.push(...(verdict.receiptIds ?? []));
    if (!verdict.allow) {
      const suppressed = await suppressFromTranslation(articleId, row.revision, receiptIds, verdict.reason ?? "original suppressed");
      return result({ status: "skipped", reason: suppressed ? (verdict.reason ?? "original suppressed") : "stale revision" });
    }
  }
  await store(articleId, row.revision, row.title, html, translatedText, complete, receiptIds,
    { html: source, xArticle: !!article });
  return result({ status: complete ? "translated" : "partial", segments: done });
}

async function store(articleId: string, revision: number, title: string, html: string, text: string, complete: boolean, receiptIds: number[], source?: { html: string; xArticle?: boolean; exact?: boolean }) {
  // Never over a translation of a later revision (a slow run finishing after a newer one).
  await sql.begin(async (tx) => {
    // A layout refresh can finish while the model is answering the same semantic revision.
    // Serialize with material writes and attach the answer to the current presentation.
    const [current] = await tx<{ revision: number; body_html: string | null; x_html: string | null; x_text: string | null }[]>`
      SELECT revision,body_html,x_article->>'html' AS x_html,x_post->>'text' AS x_text FROM articles WHERE id=${articleId} FOR UPDATE`;
    const currentHtml = source?.xArticle && current?.x_html ? xArticleBody(current.x_text ?? "", current.x_html) : current?.body_html ?? "";
    if (source?.exact && (current?.revision !== revision || currentHtml !== source.html)) throw new Error("Translation source changed; import rejected");
    if (source && current?.revision === revision && currentHtml !== source.html) {
      html = rebaseTranslation(source.html, currentHtml, html);
    }
    const changed = await tx`
      INSERT INTO translations (article_id, lang, revision, title, body_html, body_text, complete, origin)
      VALUES (${articleId}, 'zh', ${revision}, ${title}, ${html}, ${text}, ${complete}, 'model')
      ON CONFLICT (article_id, lang) DO UPDATE SET revision = EXCLUDED.revision, title = EXCLUDED.title, body_html = EXCLUDED.body_html,
        body_text = EXCLUDED.body_text, complete = EXCLUDED.complete, origin = 'model', created_at = now()
      WHERE translations.origin <> 'source' AND translations.revision <= EXCLUDED.revision
        AND (translations.revision, translations.title, translations.body_html, translations.body_text, translations.complete, translations.origin)
          IS DISTINCT FROM (EXCLUDED.revision, EXCLUDED.title, EXCLUDED.body_html, EXCLUDED.body_text, EXCLUDED.complete, EXCLUDED.origin)
      RETURNING article_id`;
    if (changed.length) await emit("articleChanged", { id: articleId, kind: "body", reason: "body translation" }, tx);
    for (const receiptId of new Set(receiptIds)) await completeReceipt(tx, receiptId);
  });
}

/** Restore an externally generated model translation only against its exact source body.
 * Importers keep model credentials and execution outside reader requests; publisher translations
 * retain priority, and the original revision checks and module notifications still apply.
 */
export async function importBodyTranslation(input: { articleId: string; sourceHtml: string; title: string; html: string; complete: boolean }) {
  const [row] = await sql<{ revision: number }[]>`SELECT revision FROM articles WHERE id=${input.articleId}`;
  if (!row) throw new Error("Translation article missing");
  const clean = sanitizeBody(input.html);
  const text = cheerio.load(clean, null, false).root().text().trim();
  if (!clean || !text) throw new Error("Empty translation");
  const reviewer = editorialPolicy().reviewTranslation;
  let receiptIds: number[] = [];
  if (reviewer) {
    const sourceText = mergeDistinctText(htmlBlockText(input.sourceHtml), htmlAltText(input.sourceHtml));
    const reviewTranslatedText = mergeDistinctText(htmlBlockText(clean), htmlAltText(clean), text);
    const verdict = await reviewer({ subject: `article:${input.articleId}@${row.revision}`, title: input.title, sourceText, translatedText: reviewTranslatedText });
    receiptIds = verdict.receiptIds ?? [];
    if (!verdict.allow) {
      await suppressFromTranslation(input.articleId, row.revision, receiptIds, verdict.reason ?? "imported translation suppressed");
      throw new Error(`Imported translation rejected by compliance: ${verdict.reason ?? "original suppressed"}`);
    }
  }
  await store(input.articleId, row.revision, input.title, clean, text, input.complete, receiptIds, { html: input.sourceHtml, exact: true });
}

/** A quoted post worth translating: at least a few letters beyond its links, and not already Chinese. */
function quoteTranslatable(text: string): boolean {
  const words = collapseWhitespace(text.replace(/https?:\/\/\S+/g, " "));
  return words.length >= 10 && (words.match(/\p{L}/gu) ?? []).length >= 2 && !isChineseText(words);
}

/**
 * The posts that selected X posts of the last `days` quote, translated once per quoted post: the
 * translation of the quoted post's own item is reused when it was collected and translated, else
 * DeepSeek (the translate model) translates it. Returns how many were stored.
 */
export async function translateQuotes(opts: { days?: number; limit?: number; budgetMs?: number } = {}): Promise<number> {
  const started = Date.now();
  const rows = await sql<{ tweet_id: string; text: string; text_hash: string | null; own_zh: string | null }[]>`
    SELECT DISTINCT ON (q.tweet_id) q.tweet_id, a.x_post->'quoted'->>'text' AS text, qt.text_hash,
      (SELECT tr.body_text FROM articles o JOIN translations tr ON tr.article_id = o.id AND tr.lang = 'zh' AND tr.revision >= o.revision
       WHERE o.identity_key = 'x:' || q.tweet_id AND tr.complete AND coalesce(tr.body_text, '') <> ''
         -- A post with a saved long article is translated as that article: its translation is not the post's words.
         AND coalesce(o.x_article->>'text', '') = '') AS own_zh
    FROM publications p JOIN articles a ON a.id = p.article_id
    CROSS JOIN LATERAL (SELECT coalesce(a.x_post->'quoted'->>'tweetId', substring(a.x_post->'quoted'->>'url' from '/status/([0-9]+)')) AS tweet_id) q
    LEFT JOIN quote_translations qt ON qt.tweet_id = q.tweet_id
    WHERE p.channel = 'x' AND p.selected AND p.visibility = 'public' AND p.body_mode = 'full'
      AND p.discovered_at > now() - make_interval(days => ${opts.days ?? 3})
      AND q.tweet_id IS NOT NULL AND coalesce(a.x_post->'quoted'->>'text', '') <> ''
    ORDER BY q.tweet_id, p.discovered_at DESC`;
  const reviewer = editorialPolicy().reviewTranslation;
  const suppressCiting = async (tweetId: string, receiptIds: number[], reason: string) => {
    const cited = await sql<{ id: string; revision: number }[]>`
      SELECT a.id, a.revision FROM articles a JOIN publications p ON p.article_id = a.id
      WHERE coalesce(a.x_post->'quoted'->>'tweetId', substring(a.x_post->'quoted'->>'url' from '/status/([0-9]+)')) = ${tweetId} AND NOT p.suppress_original`;
    for (const { id, revision } of cited) await suppressFromTranslation(id, revision, [], reason);
    if (receiptIds.length) {
      await sql.begin(async (tx) => {
        for (const id of new Set(receiptIds)) await completeReceipt(tx, id);
      });
    }
  };
  let stored = 0;
  for (const r of rows) {
    if (stored >= (opts.limit ?? 30) || Date.now() - started > (opts.budgetMs ?? 2 * 60_000) || shutdownSignal.signal.aborted) break;
    const hash = sha256(r.text);
    if (r.text_hash === hash || !quoteTranslatable(r.text)) continue;
    let zh = r.own_zh;
    let origin: "reused" | "model" = "reused";
    let receiptId: number | null = null;
    if (!zh) {
      origin = "model";
      try {
        const res = await chatJson({
          model: await modelFor("translate"), purpose: "translate_quoted", subject: `quote:${r.tweet_id}`, promptVersion: TRANSLATE_PROMPT_VERSION,
          system: SYSTEM_POST, user: JSON.stringify({ segments: [r.text] }), schema: Output, temperature: 0.2,
          maxTokens: Math.min(4000, Math.ceil(r.text.length * 1.5) + 200), timeoutMs: 120_000,
        });
        receiptId = res.receiptId;
        zh = res.data.t.length === 1 ? res.data.t[0]!.trim() : null;
      } catch (error) {
        if (reviewer && providerContentRefused(error)) {
          const verdict = await reviewer({ subject: `quote:${r.tweet_id}`, title: "", sourceText: r.text, translatedText: "", contentRefused: true });
          if (!verdict.allow) {
            await suppressCiting(r.tweet_id, verdict.receiptIds ?? [], verdict.reason ?? "quoted translation refused");
            continue;
          }
        }
        // What ends the run ends it; any other failure skips its post (an answer received is reused
        // next time, so a retry costs nothing).
        if (endsRun(error)) throw error;
        continue;
      }
    }
    if (!zh) continue;
    const allReceipts = receiptId !== null ? [receiptId] : [];
    if (reviewer) {
      const verdict = await reviewer({ subject: `quote:${r.tweet_id}`, title: "", sourceText: r.text, translatedText: zh });
      allReceipts.push(...(verdict.receiptIds ?? []));
      if (!verdict.allow) {
        await suppressCiting(r.tweet_id, allReceipts, verdict.reason ?? "quoted original suppressed");
        continue;
      }
    }
    const changed = await sql.begin(async (tx) => {
      const saved = await tx`
        INSERT INTO quote_translations (tweet_id, text_hash, text_zh, origin) VALUES (${r.tweet_id}, ${hash}, ${zh}, ${origin})
        ON CONFLICT (tweet_id) DO UPDATE SET text_hash = EXCLUDED.text_hash, text_zh = EXCLUDED.text_zh, origin = EXCLUDED.origin, created_at = now()
        WHERE (quote_translations.text_hash, quote_translations.text_zh, quote_translations.origin)
          IS DISTINCT FROM (EXCLUDED.text_hash, EXCLUDED.text_zh, EXCLUDED.origin)
        RETURNING tweet_id`;
      if (saved.length) {
        const cited = await tx<{ id: string }[]>`
          SELECT a.id FROM articles a JOIN publications p ON p.article_id = a.id
          WHERE coalesce(a.x_post->'quoted'->>'tweetId', substring(a.x_post->'quoted'->>'url' from '/status/([0-9]+)')) = ${r.tweet_id}`;
        for (const { id } of cited) await emit("articleChanged", { id, kind: "body", reason: "quoted post translation" }, tx);
      }
      for (const id of new Set(allReceipts)) await completeReceipt(tx, id);
      return saved.length > 0;
    });
    if (changed) stored += 1;
  }
  return stored;
}

/**
 * Every few minutes: selected full-text items discovered or revised in the last three days that lack a
 * translation of their current revision, then the posts selected X posts quote. Stops after a time
 * budget. A translation of an older revision is not shown (items.ts), so a revised item is translated
 * again whatever its age. Three failed attempts give an item up; only failures of the item itself count.
 */
export async function translatePending(opts: { limit?: number; budgetMs?: number } = {}): Promise<{ done: TranslateResult[]; quotes: number }> {
  const started = Date.now();
  const pending = await sql<{ article_id: string; revision: number; language: string | null; text: string | null }[]>`
    SELECT p.article_id,a.revision,a.language,
      CASE WHEN p.channel='x' THEN coalesce(nullif(a.x_article->>'text',''),a.x_post->>'text',a.body_text) ELSE a.body_text END AS text
    FROM publications p JOIN articles a ON a.id = p.article_id
    LEFT JOIN translations tr ON tr.article_id = p.article_id AND tr.lang = 'zh'
    WHERE p.selected AND p.visibility = 'public' AND p.body_mode = 'full'
      AND (p.channel='x' OR a.body_html IS NOT NULL)
      AND (p.discovered_at > now() - interval '3 days'
           OR EXISTS (SELECT 1 FROM article_revisions r WHERE r.article_id = a.id AND r.revision = a.revision AND r.revision > 1
                      AND r.created_at > now() - interval '3 days'))
      AND (tr.article_id IS NULL OR (tr.origin <> 'source' AND tr.revision < a.revision))
      AND NOT EXISTS (SELECT 1 FROM translation_attempts t WHERE t.article_id = p.article_id AND t.revision = a.revision
                      AND (t.outcome IN ('translated', 'partial') OR t.attempts >= 3
                        OR (t.outcome='skipped' AND t.reason NOT IN ('already Chinese','no foreign-language body'))))
    ORDER BY p.discovered_at DESC`;
  // Reconsider language skips with the shared rule. Filter before taking the batch so Chinese
  // originals do not occupy every slot and starve foreign-language bodies behind them.
  const rows = pending.filter(row => !isChineseText(row.text ?? "", row.language)).slice(0, opts.limit ?? 30);
  const done: TranslateResult[] = [];
  for (const r of rows) {
    if (Date.now() - started > (opts.budgetMs ?? 4 * 60_000) || shutdownSignal.signal.aborted) break;
    let outcome: "translated" | "partial" | "skipped" | "failed";
    let reason: string | null = null;
    // Bind the read as well as success and failure to this revision. A rejected old request must not
    // consume a corrected body's retry budget, or overwrite a newer run's attempt.
    const revision = r.revision;
    try {
      const result = await translateArticle(r.article_id, revision);
      done.push(result);
      outcome = result.status;
      reason = result.reason ?? null;
    } catch (error) {
      // A deploy stops between paid fragments, never aborts a sent request. Received answers stay
      // in receipts and are reused next run; do not mark an interrupted article terminal/partial.
      // Any error once the stop began is that interruption, also a sent batch the provider then refused.
      if (shutdownSignal.signal.aborted || endsRun(error)) return { done, quotes: 0 };
      // A request that may have been billed waits for its release (operations/recover.ts), which lets
      // the item's next attempt call again; meanwhile the other items go on.
      if (failureKind(error) === "unknown") continue;
      const message = (error as Error).message;
      done.push({ articleId: r.article_id, status: "skipped", reason: message.slice(0, 200) });
      outcome = "failed";
      reason = message.slice(0, 300);
    }
    await sql`
      INSERT INTO translation_attempts (article_id, revision, attempts, outcome, reason)
      SELECT ${r.article_id}, ${revision}, 1, ${outcome}, ${reason} FROM articles a WHERE a.id = ${r.article_id}
      ON CONFLICT (article_id) DO UPDATE SET
        attempts = CASE WHEN translation_attempts.revision = EXCLUDED.revision THEN translation_attempts.attempts + 1 ELSE 1 END,
        revision = EXCLUDED.revision, outcome = EXCLUDED.outcome, reason = EXCLUDED.reason, updated_at = now()
      WHERE translation_attempts.revision <= EXCLUDED.revision`;
  }
  const budgetMs = opts.budgetMs ?? 4 * 60_000;
  let quotes = 0;
  const left = budgetMs - (Date.now() - started);
  if (left > 0 && !shutdownSignal.signal.aborted) {
    try {
      quotes = await translateQuotes({ budgetMs: left });
    } catch (error) {
      if (endsRun(error)) return { done, quotes };
      throw error;
    }
  }
  return { done, quotes };
}
