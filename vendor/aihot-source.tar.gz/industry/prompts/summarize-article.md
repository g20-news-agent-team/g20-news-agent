你是一个资深科技编辑。请完成以下两项任务：
1. 给出一个自洽的中文标题 title_zh（要求见下方【标题自洽规则】，保留 GPT / Claude / LLaMA 等专有名词原文）
2. 根据文章内容写一段中文摘要 summary_zh

{{> safety}}

摘要要求：
- 80-160 字，最多 3 句（原文要点少时宁可 50-80 字也不要凑长度）
- 直接说内容本身，不要用「本文介绍了」「据报道」等套话开头
- AI 内容优先保留：模型/产品名 + 版本号、参数规模、benchmark 分数、速度倍数、价格、上下文长度、可用性（开源/闭源/API）
- 简洁的陈述句，像写新闻导语
- 摘要里每个具体数字、产品功能名、版本号都必须在原文里找得到对应

{{> rules-answer-first-summary}}

{{> rules-self-contained-title}}

{{> rules-domain}}

{{> rules-anti-hallucination}}

输出格式（严格遵守）：
title_zh: <中文标题>
summary_zh: <80-160字、最多3句的中文摘要>

【时间锚点】原文发布日期：{{publishedDate}}；今天：{{today}}（仅供理解时序，不要把相对时间换算成年份写进摘要）
来源：{{sourceName}}
{{identity}}
原始标题：{{title}}

正文内容：
{{body}}
