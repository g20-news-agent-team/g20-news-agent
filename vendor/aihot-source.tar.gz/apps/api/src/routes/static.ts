// Discovery and static files: sitemap, llms.txt, the site's public files (robots.txt, security.txt, the web
// manifest, the OpenAPI document), icons, the IndexNow key and the about page's contact codes.
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import { EDITION_TIMES, SITE } from "@aihot/site";
import { CONTACT_ALIASES, PUBLIC_INTERFACE_VERSION, robotsForReaders } from "@aihot/contracts/http-policy";
import { PUBLIC_API_CATEGORY_KEYS } from "@aihot/contracts/taxonomy";
import { REPO_ROOT, config } from "@aihot/backend/config";
import { applyPublicHeaders, etagMatches, sendTextWithEtag } from "../http/respond.ts";
import { loadSitemap } from "@aihot/backend/publication/sitemap";
import { llmsTxt, loadLlmsAvailability } from "@aihot/backend/publication/llms";
import { loadContact } from "@aihot/backend/site/contact";

const PUBLIC = path.join(REPO_ROOT, "site/public");
/** The site's brand files (site/brand/), and how long its icons are cached. */
const BRAND = path.join(REPO_ROOT, "site/brand");
const ICON_CACHE = "public, max-age=2592000, stale-while-revalidate=604800";

const TYPES: Record<string, string> = {
  ".json": "application/json; charset=UTF-8",
  ".txt": "text/plain; charset=UTF-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".webmanifest": "application/manifest+json",
};

/**
 * A public file's `{{…}}` placeholders: the site's name, address, description, tagline and locale, the
 * reports' edition times, the public interface version and the category list (JSON-escaped in JSON files). In a JSON document, an
 * `enum` or `examples` list holding "{{categories}}" becomes the list of category keys.
 */
function fillPlaceholders(text: string, json: boolean): string {
  const values: Record<string, string> = {
    siteName: SITE.name,
    siteUrl: config.siteUrl,
    description: SITE.description,
    tagline: SITE.tagline,
    locale: SITE.locale,
    dailyTime: EDITION_TIMES.daily,
    weeklyTime: EDITION_TIMES.weekly,
    monthlyTime: EDITION_TIMES.monthly,
    version: PUBLIC_INTERFACE_VERSION,
    categoryList: PUBLIC_API_CATEGORY_KEYS.join(", "),
  };
  const filled = text.replace(/\{\{(\w+)\}\}/g, (all, key: string) => {
    const value = values[key];
    if (value === undefined) return all;
    return json ? JSON.stringify(value).slice(1, -1) : value;
  });
  if (!json || !filled.includes('"{{categories}}"')) return filled;
  const walk = (node: unknown) => {
    if (!node || typeof node !== "object") return;
    const o = node as Record<string, unknown>;
    for (const key of ["enum", "examples"]) if (Array.isArray(o[key]) && (o[key] as unknown[]).includes("{{categories}}")) o[key] = [...PUBLIC_API_CATEGORY_KEYS];
    for (const v of Object.values(o)) walk(v);
  };
  const doc: unknown = JSON.parse(filled);
  walk(doc);
  return JSON.stringify(doc, null, 2);
}

interface Entry {
  body: Buffer;
  etag: string;
}

const etagOf = (body: Buffer) => `W/"${createHash("sha256").update(body).digest("hex").slice(0, 16)}"`;

const fileCache = new Map<string, Entry & { mtime: number }>();

/** A file's bytes and ETag, read again when it changes; `fill` fills in a public file's placeholders. */
async function loadFile(file: string, fill = false): Promise<Entry> {
  const s = await stat(file);
  const cached = fileCache.get(file);
  if (cached && cached.mtime === s.mtimeMs) return cached;
  let body = await readFile(file);
  if (fill && body.includes("{{")) body = Buffer.from(fillPlaceholders(body.toString("utf8"), /\.(json|webmanifest)$/.test(file)));
  if (file === path.join(PUBLIC, "robots.txt")) body = Buffer.from(robotsForReaders(body.toString("utf8")));
  const entry = { body, etag: etagOf(body), mtime: s.mtimeMs };
  fileCache.set(file, entry);
  return entry;
}

function sendEntry(req: FastifyRequest, reply: FastifyReply, entry: Entry, opts: { type: string; cacheControl: string; publicApi?: boolean }) {
  if (opts.publicApi) applyPublicHeaders(reply);
  reply.header("Content-Type", opts.type);
  reply.header("Cache-Control", opts.cacheControl);
  reply.header("ETag", entry.etag);
  if (etagMatches(req.headers["if-none-match"], entry.etag)) return reply.code(304).send();
  return reply.send(entry.body);
}

/** A file's bytes with an ETag (304 when it matches), its type from the extension unless given; a missing one is a 404. Modules serve their own files with it. */
export async function sendFile(req: FastifyRequest, reply: FastifyReply, file: string, opts: { type?: string; cacheControl: string; publicApi?: boolean; fill?: boolean }) {
  let entry;
  try {
    entry = await loadFile(file, opts.fill);
  } catch {
    return reply.code(404).type("text/plain; charset=utf-8").send("Not found");
  }
  return sendEntry(req, reply, entry, { type: opts.type ?? TYPES[path.extname(file)] ?? "application/octet-stream", cacheControl: opts.cacheControl, publicApi: opts.publicApi });
}

export function registerStatic(app: FastifyInstance) {
  const sendSitemap = async (req: FastifyRequest, reply: FastifyReply, file: string) => {
    try {
      const { files, expiresAt } = await loadSitemap();
      const xml = files[file];
      if (xml === undefined) return reply.code(404).type("text/plain; charset=utf-8").send("Not found");
      const seconds = Math.max(0, Math.floor((expiresAt - Date.now()) / 1000));
      return sendTextWithEtag(req, reply, xml, { etagPrefix: "sitemap", cacheControl: seconds > 0 ? `public, max-age=0, s-maxage=${seconds}, must-revalidate` : "no-store", contentType: "application/xml" });
    } catch (error) {
      req.log.error({ err: error }, "sitemap unavailable");
      return reply.code(503).header("Retry-After", "300").header("Cache-Control", "no-store").send("Sitemap temporarily unavailable");
    }
  };
  app.get("/sitemap.xml", (req, reply) => sendSitemap(req, reply, "sitemap.xml"));
  app.get<{ Params: { file: string } }>("/sitemaps/:file", (req, reply) => sendSitemap(req, reply, req.params.file));

  app.get("/llms.txt", async (req, reply) => {
    const text = llmsTxt(await loadLlmsAvailability());
    applyPublicHeaders(reply, { cors: false });
    // Cached like /openapi-v1.json: a release that adds an ability is described everywhere within minutes.
    return sendTextWithEtag(req, reply, text, { etagPrefix: "llms", cacheControl: "public, max-age=300, must-revalidate", contentType: "text/plain; charset=utf-8" });
  });

  // The site's public files (site/public/), placeholders filled in; one the site does not have is a 404.
  app.get("/robots.txt", (req, reply) => sendFile(req, reply, path.join(PUBLIC, "robots.txt"), { cacheControl: "public, max-age=3600", fill: true }));
  app.get("/.well-known/security.txt", (req, reply) => sendFile(req, reply, path.join(PUBLIC, ".well-known/security.txt"), { cacheControl: "public, max-age=86400", fill: true }));
  // Cached as long as the icons it names: every page links it, so a day's lifetime was a request per reader a day.
  app.get("/manifest.webmanifest", (req, reply) => sendFile(req, reply, path.join(PUBLIC, "manifest.webmanifest"), { cacheControl: ICON_CACHE, fill: true }));
  app.get("/openapi-v1.json", (req, reply) => sendFile(req, reply, path.join(PUBLIC, "openapi-v1.json"), { cacheControl: "public, max-age=300, must-revalidate", publicApi: true, fill: true }));

  // IndexNow proves the key by a file at the site root named after it (INDEXNOW_KEY).
  if (config.indexNowKey) {
    const key: Entry = { body: Buffer.from(config.indexNowKey), etag: etagOf(Buffer.from(config.indexNowKey)) };
    app.get(`/${config.indexNowKey}.txt`, (req, reply) => sendEntry(req, reply, key, { type: TYPES[".txt"]!, cacheControl: "public, max-age=3600" }));
  }

  // The site's icons (site/brand/): the standard ones, then any others it keeps at the root.
  for (const icon of ["favicon.ico", "icon.png", "icon-192.png", "apple-icon.png", "logo.svg", ...SITE.rootIcons]) {
    app.get(`/${icon}`, (req, reply) => sendFile(req, reply, path.join(BRAND, icon), { cacheControl: ICON_CACHE }));
  }

  // Contact codes' root addresses linked from outside lead to the codes the about page shows now
  // (replacing a code changes its file name).
  for (const { slot, file } of CONTACT_ALIASES) {
    app.get(`/${file}`, async (_req, reply) => {
      const contact = await loadContact();
      return reply.code(302).header("Location", contact[`${slot}Qr`]).header("Cache-Control", "public, max-age=3600").send();
    });
  }

  // Contact codes on the about page: uploaded in the admin (content-hashed names), or shipped in the pack.
  app.get("/contact/:file", async (req, reply) => {
    const file = (req.params as { file: string }).file;
    if (!/^[\w.-]+\.(png|jpg|jpeg|webp)$/.test(file)) return reply.code(404).send();
    const hashed = /-[0-9a-f]{8}\./.test(file);
    const cacheControl = hashed ? "public, max-age=31536000, immutable" : "public, max-age=3600";
    const uploaded = path.join(config.dataDir, "uploads", file);
    const target = (await stat(uploaded).then(() => true, () => false)) ? uploaded : path.join(BRAND, "contact", file);
    return sendFile(req, reply, target, { cacheControl });
  });
}
