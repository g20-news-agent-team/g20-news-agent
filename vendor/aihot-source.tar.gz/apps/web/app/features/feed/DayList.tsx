// A page of reports grouped by Beijing day with the same rail and rows as the home timeline
// (全部动态, topics, search results).
import { IntentLink } from "../../components/ui/IntentLink";
import { useMemo } from "react";
import type { FeedItemSummary } from "@aihot/contracts/site";
import { IconChevronRight } from "../../components/icons";
import { beijingDate } from "@aihot/contracts/time";
import { byBeijingDay } from "../../lib/format";
import { markRead, useReadSet } from "../../lib/local-state";
import { DayHeader, TimelineSlot } from "./Timeline";
import { FeedItem } from "./FeedItem";
import { useT } from "../../lib/i18n";

export function DayList({ items, todayCount = null, headerAside, tagTopics, currentTopicSlug, inPicks = false }: {
  items: FeedItemSummary[];
  todayCount?: number | null;
  headerAside?: React.ReactNode;
  tagTopics?: Record<string, string>;
  currentTopicSlug?: string;
  /** Every item is a pick (a topic's list): cards leave out the 精选 badge. */
  inPicks?: boolean;
}) {
  const readSet = useReadSet();
  const today = beijingDate(Date.now());
  const days = useMemo(() => byBeijingDay(items, (it) => it.timelineAt), [items]);
  return (
    <div>
      {days.map(({ day, entries: list }, i) => (
        <section key={day} aria-label={day}>
          <DayHeader day={day} today={today} count={day === today ? todayCount : null} aside={i === 0 ? headerAside : undefined} />
          <ol className="lg:pt-1">
            {list.map((it) => (
              <TimelineSlot key={it.id} at={it.timelineAt}>
                <FeedItem item={it} read={readSet.has(it.id)} onOpen={markRead} showTags tagTopics={tagTopics} currentTopicSlug={currentTopicSlug} at={it.timelineAt} inPicks={inPicks} />
              </TimelineSlot>
            ))}
          </ol>
        </section>
      ))}
    </div>
  );
}

/**
 * Numbered pages (the list stays crawlable), with previous / next at the ends. Phones show previous,
 * "2 / 50" and next as large buttons; the numbers stay in the page for crawlers.
 */
export function Pagination({ page, pageCount, href }: { page: number; pageCount: number; href: (p: number) => string }) {
  const t = useT();
  if (pageCount <= 1) return null;
  const pages = [...new Set([1, pageCount, page - 2, page - 1, page, page + 1, page + 2].filter((p) => p >= 1 && p <= pageCount))].sort((a, b) => a - b);
  const btn = "inline-flex h-9 min-w-9 items-center justify-center rounded-full px-2.5 transition-colors touch:h-11 touch:min-w-11";
  return (
    <nav aria-label={t("分页", "Pages")} className="mt-6 flex flex-wrap items-center justify-center gap-3 lg:gap-1">
      {page > 1 && (
        <IntentLink to={href(page - 1)} className={`${btn} h-11 border border-line-strong bg-surface px-5 text-ui-body-sm text-ink-2 active:bg-bg-sunk lg:h-9 lg:px-3 lg:text-ui-label lg:text-ink-3 lg:hover:border-ink-4 lg:hover:text-ink`}>
          {t("上一页", "Previous")}
        </IntentLink>
      )}
      <span className="num px-1 text-ui-label text-ink-4 lg:hidden">
        {page} / {pageCount}
      </span>
      {pages.map((p, i) => (
        <span key={p} className="hidden items-center gap-1 lg:flex">
          {i > 0 && p - pages[i - 1]! > 1 && <span className="px-0.5 text-ink-4">…</span>}
          <IntentLink
            to={href(p)}
            aria-current={p === page ? "page" : undefined}
            className={`num ${btn} text-ui-label ${p === page ? "bg-ink font-semibold text-bg" : "text-ink-3 hover:bg-bg-sunk hover:text-ink"}`}
          >
            {p}
          </IntentLink>
        </span>
      ))}
      {page < pageCount && (
        <IntentLink to={href(page + 1)} className={`${btn} h-11 gap-0.5 border border-line-strong bg-surface px-5 text-ui-body-sm text-ink-2 active:bg-bg-sunk lg:h-9 lg:px-3 lg:text-ui-label lg:text-ink-3 lg:hover:border-ink-4 lg:hover:text-ink`}>
          {t("下一页", "Next")} <IconChevronRight size={14} />
        </IntentLink>
      )}
    </nav>
  );
}
