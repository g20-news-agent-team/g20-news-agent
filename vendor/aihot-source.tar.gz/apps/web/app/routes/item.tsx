import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Await, isRouteErrorResponse, useAsyncError, useLoaderData, useRevalidator, type ClientLoaderFunctionArgs } from "react-router";
import type { Route } from "./+types/item";
import { REPORT_NAMES, reportDateLabel, type FeedItemSummary, type SiteItemDetail, type StoryFollowupsResponse } from "@aihot/contracts/site";
import { categoryLabel, displayTagIn, topicName } from "@aihot/contracts/taxonomy";
import { monthDayEn } from "@aihot/contracts/time";
import { ITEM_COPY, SITE, withSubject } from "@aihot/site";
import { ENGLISH } from "@aihot/contracts/english";
import { linkMentions } from "@aihot/contracts/mentions";
import { addressRuns } from "@aihot/contracts/addresses";
import { cachedPage, loadOr404, pagePathname } from "../lib/api.server";
import { loadFollowups } from "../features/item/followups.server";
import { pageReuse } from "../lib/page-reuse";
import { articleLd, breadcrumbLd, pageMeta, siteUrl, titled, titleCacheSeconds } from "../lib/seo";
import { fullDateTime, timeAgo } from "../lib/format";
import { markRead } from "../lib/local-state";
import { copyText } from "../lib/clipboard";
import { SameEventBadge, SelectedBadge } from "../components/ui/Badge";
import { ScoreLabel, shownScore } from "../components/ui/Score";
import { PillTabs } from "../components/ui/Tabs";
import { Presence } from "../components/ui/Presence";
import { ArticleLayout, RailSection, useContainedScroll } from "../components/ui/Page";
import { Menu, MenuItem } from "../components/ui/Menu";
import { StarButton } from "../features/feed/parts";
import { GroupButton, GroupSources } from "../features/feed/ReadingGroup";
import { StoryFollowups } from "../features/item/StoryFollowups";
import { MediaGallery } from "../features/item/MediaGallery";
import { QuotedPost } from "../features/item/QuotedPost";
import { ArticleBody } from "../features/item/ArticleBody";
import { MentionText } from "../components/ui/MentionText";
import { ActionsSheet, inWeChat, ReaderToolbar, type ActionRow } from "../features/item/ReaderTools";
import { OutlineSheet } from "../components/ui/OutlineSheet";
import { jumpTo, useSwapped } from "../lib/motion";
import { takePreview } from "../features/item/preview";
import { IconArrowLeft, IconCopy, IconDownload, IconExternal, IconImage, IconList, IconMore, IconShare } from "../components/icons";
import { BarButton, PhoneBar } from "../components/shell/PhoneBar";
import { historyIndex, isPhone, type Screen } from "../components/shell/screens";
import { Link, useNavigate } from "../lib/link";
import { apiIn, localeOf, localizePath, translator, useLocale, useT, type Locale } from "../lib/i18n";

export const handle: Screen = { home: "featured", toolbar: true };
export { pageHeaders as headers } from "../lib/api.server";

const PosterSheet = lazy(() => import("../features/item/PosterSheet"));

export async function loader({ params, request }: Route.LoaderArgs) {
  const locale = localeOf(pagePathname(request));
  const item = await loadOr404<SiteItemDetail>(apiIn(`/items/${encodeURIComponent(params.id)}`, locale), { signal: request.signal });
  return cachedPage(titleCacheSeconds(600, locale, item.indexable ? item.title : null), { item, followups: await loadFollowups(item, locale, request.signal) });
}

type Loaded = { item: SiteItemDetail; followups: StoryFollowupsResponse | null };
type Preview = { item: null; preview: FeedItemSummary; detail: Promise<Loaded> };

/**
 * Phones: an article tapped in a list opens at once with what the card showed (title, summary, reason),
 * while its full text loads. Opened any other way, or on desktop, the page waits for its data as usual.
 */
const reuse = pageReuse<typeof loader>();
export const { shouldRevalidate } = reuse;
export async function clientLoader(args: ClientLoaderFunctionArgs) {
  const { params } = args;
  const preview = isPhone() && params.id ? takePreview(params.id) : null;
  if (!preview) return reuse.clientLoader(args);
  return { item: null, preview, detail: reuse.clientLoader(args) } satisfies Preview;
}
clientLoader.hydrate = true as const;

export function meta({ loaderData, location }: Route.MetaArgs) {
  const locale = localeOf(location.pathname);
  const t = translator(locale);
  if (!loaderData) return [{ title: titled(t("内容不存在", "Article not found")) }, { name: "robots", content: "noindex" }];
  const { item } = loaderData;
  if (!item) return [{ title: titled(loaderData.preview.title) }];
  const section = [...new Set([...(item.category ? [categoryLabel(item.category, locale)] : []), ...item.topics.map((topic) => topicName(topic.slug, topic.name, locale))])];
  return pageMeta({
    locale,
    title: item.title,
    description: item.summary ?? undefined,
    path: `/items/${item.id}`,
    image: `/og/items/${item.id}.png`,
    type: "article",
    noindex: !item.indexable,
    googleNoindex: item.googleNoindex,
    jsonLd: [
      articleLd({ locale, path: `/items/${item.id}`, headline: item.title, description: item.summary, publishedAt: item.publishedAt ?? item.discoveredAt, image: `/og/items/${item.id}.png`, basedOn: item.links.original, section }),
      breadcrumbLd([
        { name: SITE.name, path: "/" },
        { name: item.selected ? t("精选", "Top Picks") : t("全部动态", `All ${SITE.subject} News`), path: item.selected ? "/" : "/all" },
        { name: item.title, path: `/items/${item.id}` },
      ], locale),
    ],
  });
}

/** A 2px accent line across the top that follows long bodies. */
function ReadingProgress() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const max = document.documentElement.scrollHeight - window.innerHeight;
      if (ref.current) ref.current.style.transform = `scaleX(${max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0})`;
    };
    const schedule = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
    };
  }, []);
  // It follows the scroll as it happens: a transition would trail the reader's thumb.
  return <div ref={ref} aria-hidden="true" className="fixed inset-x-0 top-0 z-50 h-[2px] origin-left bg-accent" style={{ transform: "scaleX(0)" }} />;
}

/**
 * The outline takes what is left of its rail and scrolls within it; with room for fewer than six entries it
 * keeps six (an entry is its 12.5px line at leading-snug plus 8px of padding, 44px on touch screens), and the
 * rail scrolls instead.
 */
function ArticleOutline({ outline }: { outline: SiteItemDetail["outline"] }) {
  const t = useT();
  const [nav, overscroll] = useContainedScroll<HTMLElement>();
  const containKeys = (e: React.KeyboardEvent<HTMLElement>) => {
    const nav = e.currentTarget;
    if (nav.scrollHeight <= nav.clientHeight || e.altKey || e.ctrlKey || e.metaKey) return;
    const up = ["ArrowUp", "PageUp", "Home"].includes(e.key) || (e.key === " " && e.shiftKey);
    const down = ["ArrowDown", "PageDown", "End"].includes(e.key) || (e.key === " " && !e.shiftKey);
    // WebKit can chain keyboard scrolling even with overscroll-behavior: contain.
    if ((up && nav.scrollTop <= 0) || (down && nav.scrollTop + nav.clientHeight >= nav.scrollHeight - 1)) e.preventDefault();
  };
  return (
    <RailSection title={t("本文目录", "Contents")} shrink>
      <nav ref={nav} aria-label={t("本文目录", "Contents")} tabIndex={overscroll ? 0 : undefined} onKeyDown={containKeys} className={`scrollbar-thin min-h-[calc(6*(12.5px*1.375+8px))] overflow-y-auto touch:min-h-[calc(6*2.75rem)] ${overscroll}`}>
        <ol className="space-y-0.5 border-l border-line">
          {outline.map((o) => (
            <li key={o.id}>
              <a href={`#${o.id}`} onClick={(e) => jumpTo(e, o.id)} className={`-ml-px block border-l border-transparent py-1 text-ui-caption-lg leading-snug text-ink-3 transition-colors hover:border-accent hover:text-ink focus-visible:outline-offset-[-2px] touch:flex touch:min-h-11 touch:items-center ${o.level > 2 ? "pl-5" : "pl-3"}`}>
                {o.text}
              </a>
            </li>
          ))}
        </ol>
      </nav>
    </RailSection>
  );
}

function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

/** The byline, unless the source's name already says it (公众号：卡尔的AI沃茨 by AI沃茨, Claude：YouTube by Claude). */
function bylineOf(author: string | null, source: string): string | null {
  const key = (s: string) => s.toLowerCase().replace(/[\s\p{P}]/gu, "");
  const a = author ? key(author) : "";
  const s = key(source);
  return a && !s.includes(a) && !a.includes(s) ? author : null;
}

/** "11月7日 AI 日报 · 头条" / "AI Daily, Nov 7 · Lead story": the daily that carries the article, named as the site names its issues. */
function dailyName(daily: NonNullable<SiteItemDetail["daily"]>, locale: Locale): string {
  const t = translator(locale);
  return t(
    `${reportDateLabel("daily", daily.key)} ${withSubject(REPORT_NAMES.daily)}${daily.lead ? " · 头条" : ""}`,
    `${SITE.subject} Daily, ${monthDayEn(daily.key)}${daily.lead ? " · Lead story" : ""}`,
  );
}

/**
 * The tag chips that go beside the article's topic chips (every place showing tags shows all its topics): a
 * tag that is a topic's own leads to the topic's page, not to a filtered list search engines are kept from,
 * and beside that topic's chip it is not repeated.
 */
function tagChips(item: SiteItemDetail, locale: Locale): Array<{ tag: string; label: string; to: string }> {
  const shown = new Set(item.topics.map((topic) => topic.slug));
  return item.tags.flatMap((tag) => {
    const label = displayTagIn(tag, locale);
    if (!label) return [];
    const topic = item.tagTopics[tag];
    if (topic && shown.has(topic)) return [];
    return [{ tag, label, to: topic ? `/topics/${topic}` : `/all?tag=${encodeURIComponent(tag)}` }];
  });
}

/** Touch screens with a system share sheet share through it; elsewhere sharing is copying the link. */
function sharesBySheet(): boolean {
  return typeof navigator !== "undefined" && !!navigator.share && matchMedia("(pointer: coarse)").matches;
}

/** 分享: the system share sheet where there is one; otherwise, or when it fails other than by the reader cancelling, the link is copied. */
async function shareOrCopy(item: Pick<SiteItemDetail, "id" | "title">, locale: Locale, notify: (text: string, problem?: boolean) => void): Promise<void> {
  const t = translator(locale);
  const url = `${siteUrl()}${localizePath(`/items/${item.id}`, locale)}`;
  if (sharesBySheet()) {
    try {
      await navigator.share({ title: item.title, url });
      return;
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return;
    }
  }
  try {
    await copyText(`${item.title}\n${url}`);
    notify(t("链接已复制", "Link copied"));
  } catch {
    notify(t("复制失败", "Couldn't copy"), true);
  }
}

/**
 * A short line over the page's foot, gone after a moment (longer for one that says something went wrong). Shown
 * again while it is up, it stays for its full time again.
 */
function useToast(): [string | null, (text: string, problem?: boolean) => void] {
  const [toast, setToast] = useState<{ text: string; problem: boolean } | null>(null);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), toast.problem ? 2400 : 1600);
    return () => clearTimeout(t);
  }, [toast]);
  return [toast?.text ?? null, (text, problem = false) => setToast({ text, problem })];
}

function Toast({ text }: { text: string | null }) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-[calc(80px+env(safe-area-inset-bottom))] z-50 flex justify-center lg:bottom-8">
      <Presence show={!!text} motion="float">
        <div role="status" className="rounded-full bg-ink px-4 py-2 text-ui-label text-bg shadow-[var(--shadow-pop)]">
          {text}
        </div>
      </Presence>
    </div>
  );
}


export default function ItemPage() {
  const data = useLoaderData<typeof clientLoader>() as Loaded | Preview;
  if (data.item) return <ItemView key={data.item.id} item={data.item} followups={data.followups} />;
  return (
    <Suspense fallback={<ItemPreview preview={data.preview} />}>
      <Await resolve={data.detail} errorElement={<ItemGone />}>
        {(loaded) => <ItemView key={loaded.item.id} item={loaded.item} followups={loaded.followups} arrived />}
      </Await>
    </Suspense>
  );
}

/** Phones, while the article loads: what the card showed, in the article's own places. */
function ItemPreview({ preview }: { preview: FeedItemSummary }) {
  const t = useT();
  const locale = useLocale();
  const [toast, setToast] = useToast();
  const isX = preview.channel === "x" && !!preview.x;
  // A post reads under its author; one that publishes a long X Article reads like an article, under its headline.
  const isPost = isX && !preview.x!.article;
  // Without a reliable date from the original, the card's time is when it was collected, and says so.
  const shownAt = preview.publishedAt ?? preview.timelineAt;
  return (
    <div className="mx-auto max-w-[var(--page-max-reading)] pb-8">
      {/* 更多 is there while loading too, so the bar does not change when the article arrives. */}
      <PhoneBar
        back={{ to: preview.selected ? "/" : "/all", label: preview.selected ? t("精选", "Top Picks") : t("全部", "All") }}
        title={isPost ? preview.x!.authorName : preview.title}
        actions={
          <BarButton label={t("更多操作", "More actions")} disabled className="disabled:opacity-40">
            <IconMore size={22} />
          </BarButton>
        }
      />
      <article className="pb-6 pt-3" aria-busy="true">
        <div className={`flex flex-wrap items-center gap-x-1.5 gap-y-1 text-ui-label text-ink-3 ${isPost ? "" : "mb-3"}`}>
          <span className="font-semibold text-ink-2">{isX ? preview.x!.authorName : preview.source.name}</span>
          {isX && <span>· @{preview.x!.handle} · X</span>}
          <span>·</span>
          {!preview.publishedAt && <span>{t("收录时间", "Added")}</span>}
          <time dateTime={shownAt} className="mono">{fullDateTime(shownAt)}</time>
          {preview.selected && <span className="ml-1">{preview.sameEvent ? <SameEventBadge /> : <SelectedBadge />}</span>}
          {shownScore(preview.score) !== null && (
            <span className="ml-1">
              <ScoreLabel score={preview.score} />
            </span>
          )}
        </div>
        {isPost ? <h1 className="sr-only">{preview.title}</h1> : <h1 data-page-title="" className="text-ui-title-2 font-bold leading-[1.38] tracking-[-0.01em] text-ink">{preview.title}</h1>}
        {preview.summary && (
          <section className={isPost ? "mt-4" : "mt-7"}>
            <div className="mb-2 text-ui-caption font-semibold text-accent">{isPost && preview.summary.replace(/\s+/g, " ").trim() === preview.title ? t("原文", "Original") : t("AI 导读", "AI brief")}</div>
            <p className="text-ui-heading-sm leading-[1.7] text-ink"><MentionText runs={addressRuns(preview.summary)} /></p>
          </section>
        )}
        {preview.reason && (
          <section className="mt-6 border-t border-line pt-4">
            <div className="mb-1 text-ui-caption font-semibold text-ink-3">{t(ITEM_COPY.reasonLabel, ENGLISH?.reasonLabel ?? ITEM_COPY.reasonLabel)}</div>
            <p className="text-ui-body leading-[1.75] text-ink-2">{preview.reason}</p>
          </section>
        )}
        <div className="mt-9 space-y-3 border-t border-line pt-6" aria-hidden="true">
          {[92, 100, 96, 88, 98, 64].map((w, i) => (
            <div key={i} className="skeleton h-4" style={{ width: `${w}%` }} />
          ))}
        </div>
      </article>
      <ReaderToolbar
        item={preview}
        originalLabel={isX ? t("原推", "View on X") : t("原文", "Original")}
        onShare={() => void shareOrCopy(preview, locale, setToast)}
      />
      <Toast text={toast} />
    </div>
  );
}

/** The article could not load after the tap: gone (withdrawn, merged away), or the service is busy. */
function ItemGone() {
  const t = useT();
  const error = useAsyncError();
  const revalidator = useRevalidator();
  const gone = isRouteErrorResponse(error) && error.status === 404;
  return (
    <div className="mx-auto max-w-sm pb-8">
      <PhoneBar back={{ to: "/", label: t("精选", "Top Picks") }} />
      <div className="py-24 text-center">
        <div className="text-ui-heading font-bold text-ink">{gone ? t("找不到这篇内容", "Article not found") : t("暂时无法加载", "Can't load this page")}</div>
        <p className="mt-2 text-ui-label-lg leading-relaxed text-ink-3">{gone ? t("链接可能有误，或者这篇内容已经下架。", "The link may be wrong, or this article has been taken down.") : t("服务暂时繁忙，请稍后再试。", "The service is busy right now. Please try again later.")}</p>
        {!gone && (
          <button type="button" onClick={() => void revalidator.revalidate()} className="mt-6 h-11 rounded-full border border-line-strong bg-surface px-5 text-ui-body-sm font-medium text-ink-2 active:bg-bg-sunk">
            {t("重试", "Try again")}
          </button>
        )}
      </div>
    </div>
  );
}

/** `arrived`: shown in place of the phone's preview, its text fading in over the placeholder lines. */
function ItemView({ item, followups, arrived = false }: Loaded & { arrived?: boolean }) {
  const t = useT();
  const locale = useLocale();
  const navigate = useNavigate();
  const hasTranslation = item.hasTranslation;
  const lang = item.bodyLanguage;
  const [posterRequested, setPosterRequested] = useState(false);
  const [posterOpen, setPosterOpen] = useState(false);
  const [outlineOpen, setOutlineOpen] = useState(false);
  const [actionsOpen, setActionsOpen] = useState(false);
  const [toast, setToast] = useToast();
  useEffect(() => { markRead(item.id); }, [item.id]);
  // Switched between 中文 and 原文, the new text fades in where the old one was while the bars, the toolbar and the
  // place on the page stay; arriving at the article, it is just there.
  const switched = useSwapped(lang);
  const closePoster = useCallback(() => setPosterOpen(false), []);
  const openPoster = () => {
    setPosterRequested(true);
    setPosterOpen(true);
  };
  const share = () => void shareOrCopy(item, locale, setToast);
  const copyLink = async () => {
    try {
      await copyText(`${siteUrl()}${localizePath(`/items/${item.id}`, locale)}`);
      setToast(t("链接已复制", "Link copied"));
    } catch {
      setToast(t("复制失败", "Couldn't copy"), true);
    }
  };
  const copyMarkdown = async () => {
    try {
      const res = await fetch(`/items/${item.id}/markdown`);
      if (!res.ok) throw new Error(String(res.status));
      await copyText(await res.text());
      setToast(t("Markdown 已复制", "Markdown copied"));
    } catch {
      setToast(t("复制失败，请在浏览器中打开后导出", "Couldn't copy. Open this page in a browser to export it."), true);
    }
  };

  const bodyHtml = lang === "zh" ? (item.body?.zh ?? item.body?.original) : (item.body?.original ?? item.body?.zh);
  const bodyLabel = !item.body ? null : lang === "zh" && item.body.zhKind === "translation" ? t("正文 · AI 翻译", "Full text · AI translation") : lang === "original" ? t("正文 · 原文", "Full text · Original") : t("正文", "Full text");
  const isX = item.channel === "x" && !!item.x;
  // A post reads under its author; one that publishes a long X Article reads like an article, under its headline.
  const isPost = isX && !item.x!.article;
  const byline = isX ? null : bylineOf(item.author, item.source.name);
  // Without a reliable date from the original, the time shown is when it was collected, labelled as such.
  const shownAt = item.publishedAt ?? item.discoveredAt;
  const timeLabel = item.publishedAt ? t("发布时间", "Published") : t("收录时间", "Added");
  const summaryOnly = item.readingMode === "summary-only";
  const showOutline = item.outline.length >= 3;
  const originalLabel = isX ? t("在 X 查看原推", "View on X") : t("打开原文", "Open original");

  const related = item.relatedStories.filter((s) => s.publicId !== item.story?.publicId);
  const [summaryRuns] = useMemo(() => linkMentions([item.summary], item.mentions), [item.summary, item.mentions]);
  const daily = item.daily && { to: `/daily/${item.daily.key}`, name: dailyName(item.daily, locale) };
  const tags = tagChips(item, locale);
  const reasonLabel = t(ITEM_COPY.reasonLabel, ENGLISH?.reasonLabel ?? ITEM_COPY.reasonLabel);

  const back = () => {
    if (historyIndex() > 0) navigate(-1);
    else navigate(item.selected ? "/" : "/all");
  };
  // In the left rail (a flex column) it keeps its own height and width.
  const backButton = (
    <button type="button" onClick={back} className="-ml-1.5 inline-flex h-8 shrink-0 items-center gap-1.5 self-start rounded-full px-1.5 text-ui-label text-ink-3 transition-colors hover:text-ink touch:h-11">
      <IconArrowLeft size={16} />{t(" 返回", " Back")}
    </button>
  );
  const moreMenu = (
    <Menu label={t("更多操作", "More actions")} trigger={<IconMore size={18} />}>
      {(close) => (
        <>
          {/* With a mouse sharing is copying the link, which 复制链接 already does. */}
          {sharesBySheet() && <MenuItem icon={<IconShare size={15} />} onSelect={() => { close(); share(); }}>{t("分享链接", "Share link")}</MenuItem>}
          <MenuItem icon={<IconImage size={15} />} onSelect={() => { close(); openPoster(); }}>{t("生成分享海报", "Share as image")}</MenuItem>
          <MenuItem icon={<IconCopy size={15} />} onSelect={() => { close(); void copyLink(); }}>{t("复制链接", "Copy link")}</MenuItem>
          {item.markdownAvailable &&
            (inWeChat() ? (
              <MenuItem icon={<IconDownload size={15} />} onSelect={() => { close(); void copyMarkdown(); }}>{t("复制 Markdown", "Copy as Markdown")}</MenuItem>
            ) : (
              <MenuItem icon={<IconDownload size={15} />} href={`/items/${item.id}/markdown`} download onSelect={close}>
                {t("导出 Markdown", "Export as Markdown")}
              </MenuItem>
            ))}
        </>
      )}
    </Menu>
  );
  // Phones: the same actions as a sheet from the bar (分享 and 原文 are on the toolbar).
  const phoneActions: ActionRow[] = [
    { key: "poster", label: t("生成分享海报", "Share as image"), icon: <IconImage size={20} />, onSelect: openPoster },
    { key: "copy", label: t("复制链接", "Copy link"), icon: <IconCopy size={20} />, onSelect: () => void copyLink() },
    ...(item.markdownAvailable
      ? [inWeChat()
        ? { key: "markdown", label: t("复制 Markdown", "Copy as Markdown"), icon: <IconDownload size={20} />, onSelect: () => void copyMarkdown() }
        : { key: "markdown", label: t("导出 Markdown", "Export as Markdown"), icon: <IconDownload size={20} />, href: `/items/${item.id}/markdown`, download: true }]
      : []),
  ];
  const originalLink = (className: string) => (
    <a
      href={item.links.original}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex h-8 items-center justify-center gap-1.5 rounded-full border border-line-strong bg-surface px-3.5 text-ui-caption-lg font-medium text-ink-2 transition-colors hover:border-ink-4 hover:text-ink ${className}`}
    >
      {originalLabel} <IconExternal size={13} />
    </a>
  );
  // Desktop actions head the right rail, one row as tall as 返回 at the head of the left one.
  const actions = (
    <div className="flex items-center gap-1">
      {originalLink("flex-1 touch:h-11")}
      <StarButton item={item} className="size-8 touch:size-11" />
      {moreMenu}
    </div>
  );
  const verdict = (item.selected || shownScore(item.score) !== null) && (
    <div className="flex items-center gap-2">
      {item.selected && (item.sameEvent ? <SameEventBadge /> : <SelectedBadge />)}
      <ScoreLabel score={item.score} />
    </div>
  );

  // Rails: the piece's facts on the left (wide screens), the editor's notes on the right, the outline
  // under the facts (or under the notes when only the right rail shows).
  const facts = (
    <RailSection title={t("来源", "Source")}>
      <div className="text-ui-body-sm font-semibold leading-snug text-ink">{isX ? item.x!.authorName : item.source.name}</div>
      <div className="mt-1 text-ui-caption-lg leading-relaxed text-ink-3">
        {isX ? `@${item.x!.handle} · X` : byline ?? hostOf(item.links.original)}
      </div>
      <div className="mt-3 text-ui-caption text-ink-4">{timeLabel}</div>
      <time dateTime={shownAt} className="mono mt-0.5 block text-ui-caption-lg text-ink-2">
        {fullDateTime(shownAt)}
      </time>
      <div className="mt-0.5 text-ui-caption text-ink-4 empty:hidden" suppressHydrationWarning>
        {timeAgo(shownAt, undefined, locale)}
      </div>
    </RailSection>
  );
  const outline = showOutline && <ArticleOutline outline={item.outline} />;
  const notes = (
    <>
      {item.reason && !summaryOnly ? (
        <RailSection title={reasonLabel}>
          {verdict && <div className="mb-3">{verdict}</div>}
          <p className="text-ui-label-lg leading-[1.8] text-ink-2">{item.reason}</p>
        </RailSection>
      ) : (
        verdict && <RailSection title={shownScore(item.score) !== null ? t("AI 评分", "AI score") : undefined}>{verdict}</RailSection>
      )}
      {daily && (
        <RailSection title={t("收录于", "Featured in")}>
          <div className="flex flex-wrap gap-1.5">
            <Link viewTransition to={daily.to} className="chip">
              {daily.name}
            </Link>
          </div>
        </RailSection>
      )}
      {item.topics.length > 0 && (
        <RailSection title={t("主题", "Topics")}>
          <div className="flex flex-wrap gap-1.5 touch:gap-y-4.5">
            {item.topics.map((topic) => (
              <Link viewTransition key={topic.slug} to={`/topics/${topic.slug}`} className="chip">
                {topicName(topic.slug, topic.name, locale)}
              </Link>
            ))}
          </div>
        </RailSection>
      )}
      {tags.length > 0 && (
        <RailSection title={t("标签", "Tags")}>
          <div className="flex flex-wrap gap-1.5 touch:gap-y-4.5">
            {tags.slice(0, 8).map(({ tag, label, to }) => (
              <Link key={tag} to={to} rel={to.startsWith("/all?") ? "nofollow" : undefined} className="chip">
                #{label}
              </Link>
            ))}
          </div>
        </RailSection>
      )}
    </>
  );

  return (
    <div className="mx-auto max-w-[var(--page-max-reading)] pb-8">
      {item.body && <ReadingProgress />}

      {/* Phones: back to where the reader came from, the title once it has scrolled away, more actions. */}
      <PhoneBar
        back={{ to: item.selected ? "/" : "/all", label: item.selected ? t("精选", "Top Picks") : t("全部", "All") }}
        title={isPost ? item.x!.authorName : item.title}
        actions={
          <BarButton label={t("更多操作", "More actions")} onClick={() => setActionsOpen(true)}>
            <IconMore size={22} />
          </BarButton>
        }
      />

      {/* The text on the page in one column; back and the facts in the left rail, actions and notes in the right. */}
      <ArticleLayout
        left={
          <>
            {backButton}
            {facts}
            {outline}
          </>
        }
        right={
          <>
            {actions}
            {notes}
            <div className="flex min-h-0 flex-col space-y-8 2xl:hidden">{outline}</div>
          </>
        }
      >
        {/* Between lg and 2xl the left rail is hidden: 返回 stays at the top while reading, as on the original site.
            Below side the right rail is hidden too, and its actions and the outline join 返回. */}
        <div className="sticky top-0 z-20 -mx-2 hidden items-center justify-between gap-3 bg-bg/95 px-2 py-1.5 backdrop-blur lg:flex 2xl:hidden">
          {backButton}
          <div className="flex items-center gap-1 side:hidden">
            {showOutline && (
              <button type="button" onClick={() => setOutlineOpen(true)} className="inline-flex h-8 items-center gap-1.5 rounded-full px-3 text-ui-caption-lg font-medium text-ink-3 transition-colors hover:bg-bg-sunk hover:text-ink touch:h-11">
                <IconList size={15} />{t(" 目录", " Contents")}
              </button>
            )}
            {originalLink("touch:h-11")}
            <StarButton item={item} className="size-8 touch:size-11" />
            {moreMenu}
          </div>
        </div>
        <article className="pb-6 pt-3 lg:pt-2 2xl:pt-1">
          <div className={`flex flex-wrap items-center gap-x-1.5 gap-y-1 text-ui-label text-ink-3 2xl:hidden ${isPost ? "" : "mb-3"}`}>
            <span className="font-semibold text-ink-2">{isX ? item.x!.authorName : item.source.name}</span>
            {isX && <span>· @{item.x!.handle} · X</span>}
            {byline && <span>· {byline}</span>}
            <span>·</span>
            {!item.publishedAt && <span>{t("收录时间", "Added")}</span>}
            <time dateTime={shownAt} className="mono">{fullDateTime(shownAt)}</time>
            <span className="empty:hidden" suppressHydrationWarning>{timeAgo(shownAt, undefined, locale) && `· ${timeAgo(shownAt, undefined, locale)}`}</span>
            {item.selected && (
              <span className="ml-1 side:hidden">
                {item.sameEvent ? <SameEventBadge /> : <SelectedBadge />}
              </span>
            )}
            {shownScore(item.score) !== null && (
              <span className="ml-1 side:hidden">
                <ScoreLabel score={item.score} />
              </span>
            )}
          </div>
          {isPost ? <h1 className="sr-only">{item.title}</h1> : <h1 data-page-title="" className="text-ui-title-2 font-bold leading-[1.38] tracking-[-0.01em] text-ink lg:text-ui-title-6 lg:leading-[1.34] xl:text-ui-display-2 xl:leading-[1.3]">{item.title}</h1>}
          {!isPost && item.originalTitle && <p className="mt-2.5 text-ui-body-sm leading-relaxed text-ink-4">{item.originalTitle}</p>}

          {item.summary && (!isPost || item.summary.replace(/\s+/g, " ").trim() !== item.title) && (
            <section className={isPost ? "mt-4" : "mt-7 xl:mt-8"}>
              <div className="mb-2 text-ui-caption font-semibold text-accent">{summaryOnly ? t("摘要", "Summary") : t("AI 导读", "AI brief")}</div>
              <p className="text-ui-heading-sm leading-[1.7] text-ink xl:text-ui-heading xl:leading-[1.7]"><MentionText runs={summaryRuns} /></p>
            </section>
          )}

          {item.reason && !summaryOnly && (
            <section className="mt-6 border-t border-line pt-4 side:hidden">
              <div className="mb-1 text-ui-caption font-semibold text-ink-3">{reasonLabel}</div>
              <p className="text-ui-body leading-[1.75] text-ink-2">{item.reason}</p>
            </section>
          )}

          {item.sameEvent && (
            <p className="mt-5 text-ui-label leading-relaxed text-ink-4">
              {t("同一件事，精选收录的是", "Same story in Top Picks: ")}
              <Link viewTransition to={`/items/${item.sameEvent.id}`} className="text-ink-3 transition-colors hover:text-accent">
                {t(<>《{item.sameEvent.title}》</>, <>“{item.sameEvent.title}”</>)}
              </Link>
            </p>
          )}

          {item.group && item.group.reportCount > 1 && (
            <div className="mt-5">
              <div className="hidden lg:block"><GroupSources group={item.group} parentId={item.id} /></div>
              <GroupButton group={item.group} parentId={item.id} />
            </div>
          )}

          {summaryOnly && <p className="mt-7 rounded-control bg-bg-sunk px-4 py-3 text-ui-label-lg leading-relaxed text-ink-3">{t("本站只提供摘要与原文链接。", "Only a summary and a link to the original are available here.")}</p>}

          {item.body && bodyHtml && (
            <section className="mt-9 border-t border-line pt-4 xl:mt-10">
              <div className="mb-6 flex items-center justify-between gap-3">
                <span className="text-ui-caption text-ink-4">{bodyLabel}</span>
                {hasTranslation && (
                  <PillTabs
                    size="xs"
                    layoutId="item-body-lang"
                    label={t("正文语言", "Full text language")}
                    active={lang}
                    items={[
                      { key: "zh", label: t("中文", "Chinese"), prefetchOnPress: true, replace: true, to: `/items/${item.id}` },
                      { key: "original", label: t("原文", "Original"), prefetchOnPress: true, replace: true, to: `/items/${item.id}/original` },
                    ]}
                  />
                )}
              </div>
              {hasTranslation && lang === "zh" && !item.body.complete && (
                <p className="mb-5 rounded-control bg-bg-sunk px-3 py-2 text-ui-label text-ink-3">{t("译文尚不完整，完整内容请切换到原文。", "The translation isn't complete yet. Switch to the original for the full text.")}</p>
              )}
              <div key={lang} className={switched || arrived ? "anim-fade-in" : undefined}>
                <ArticleBody html={bodyHtml} />
              </div>
            </section>
          )}

          {isX && item.x!.media.length > 0 && <MediaGallery media={item.x!.media} postUrl={item.links.original} />}
          {isX && item.x!.quoted?.html && <QuotedPost quoted={item.x!.quoted} original={lang === "original"} />}

          <p className="mt-8 text-ui-label text-ink-4">
            {t("来源：", "Source: ")}
            <a href={item.links.original} target="_blank" rel="noopener noreferrer" className="text-ink-3 hover:text-accent">
              {isX ? item.x!.authorName : item.source.name}
            </a>
            <span> · {hostOf(item.links.original)}</span>
          </p>

          {(daily || item.topics.length > 0 || tags.length > 0) && (
            <div className="mt-4 flex flex-wrap gap-1.5 side:hidden touch:gap-y-4.5">
              {daily && (
                <Link viewTransition to={daily.to} className="chip">
                  {t(<>收录于 {daily.name}</>, <>Featured in {daily.name}</>)}
                </Link>
              )}
              {item.topics.map((topic) => (
                <Link viewTransition key={topic.slug} to={`/topics/${topic.slug}`} className="chip">
                  {topicName(topic.slug, topic.name, locale)}
                </Link>
              ))}
              {tags.slice(0, 6).map(({ tag, label, to }) => (
                <Link key={tag} to={to} rel={to.startsWith("/all?") ? "nofollow" : undefined} className="chip">
                  #{label}
                </Link>
              ))}
            </div>
          )}

          {item.story && <StoryFollowups followups={followups} story={item.story} currentId={item.id} />}

          {related.length > 0 && (
            <section className="mt-8">
              <h2 className="mb-2 text-ui-body-sm font-semibold text-ink">{t("相关事件", "Related stories")}</h2>
              <ul className="divide-y divide-line-soft">
                {related.map((s) => (
                  <li key={s.publicId}>
                    <Link viewTransition to={`/story/${s.publicId}`} className="block py-2.5 text-ui-body-sm text-ink-2 hover:text-accent">
                      {s.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </article>
      </ArticleLayout>

      <ReaderToolbar
        item={item}
        originalUrl={item.links.original}
        originalLabel={isX ? t("原推", "View on X") : t("原文", "Original")}
        onOutline={showOutline ? () => setOutlineOpen(true) : undefined}
        onShare={share}
      />
      {showOutline && <OutlineSheet open={outlineOpen} onClose={() => setOutlineOpen(false)} outline={item.outline} />}
      <ActionsSheet open={actionsOpen} onClose={() => setActionsOpen(false)} rows={phoneActions} />

      {posterRequested && (
        <Suspense fallback={null}>
          <PosterSheet id={item.id} title={item.title} open={posterOpen} onClose={closePoster} />
        </Suspense>
      )}
      <Toast text={toast} />
    </div>
  );
}
