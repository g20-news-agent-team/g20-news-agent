// Admin sign-in: the admin password (ADMIN_PASSWORD). The form posts
// straight to the API, which sets the session cookie and sends the browser on.
import { data, redirect, useLoaderData } from "react-router";
import type { Route } from "./+types/admin-login";
import { ADMIN, SITE } from "@aihot/site";
import { safeReturn, SIGN_IN_HOME } from "@aihot/contracts/admin";
import { apiGet } from "../lib/api.server";
import { adminSignedIn } from "../lib/admin.server";
import { Wordmark } from "@aihot/site/brand/Logo.tsx";
import { buttonClass } from "../components/ui/Controls";

const ERRORS: Record<string, string> = {
  wrong: "密码不对，再试一次。",
  unset: "还没有设置管理员密码：在 .env 里设置 ADMIN_PASSWORD（至少 12 位），重启后再登录。",
  "too-many": "尝试次数太多，请 15 分钟后再试。",
};

export async function loader({ request }: Route.LoaderArgs) {
  if (!ADMIN) throw data({ message: "not_found" }, { status: 404 });
  const url = new URL(request.url);
  const target = safeReturn(url.searchParams.get("return") ?? SIGN_IN_HOME);
  // Already signed in: the sign-in page has nothing to offer; go where the visitor was headed.
  if (await adminSignedIn(request).catch(() => false)) throw redirect(target);
  const options = await apiGet<{ password: boolean }>("/api/auth/options", { signal: request.signal }).catch(() => ({ password: true }));
  return { returnTo: target, error: url.searchParams.get("error"), ...options };
}

export const meta: Route.MetaFunction = () => [{ title: `登录 · ${SITE.name} 后台` }, { name: "robots", content: "noindex, nofollow" }];

export const headers: Route.HeadersFunction = () => ({ "Cache-Control": "no-store", "X-Robots-Tag": "noindex, nofollow" });

export default function AdminLogin() {
  const { returnTo, error, password } = useLoaderData<typeof loader>();
  const message = error ? (ERRORS[error] ?? ERRORS.wrong) : !password ? ERRORS.unset : null;
  return (
    <div className="flex min-h-dvh items-center justify-center bg-bg px-4">
      <div className="w-full max-w-[360px]">
        <div className="flex items-center justify-center gap-2">
          <Wordmark size={28} className="text-ink" />
          <span className="text-ui-body font-semibold text-ink-3">后台</span>
        </div>
        <form method="post" action="/api/auth/password" className="card mt-8 p-6">
          <input type="hidden" name="return" value={returnTo} />
          <label htmlFor="password" className="block text-ui-label font-medium text-ink-2">
            管理员密码
          </label>
          <input
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            required
            autoFocus
            className="mt-2 h-10 w-full rounded-full border border-line-strong bg-surface px-4 text-ui-body-sm text-ink outline-none transition-colors focus:border-accent"
          />
          {message && (
            <p role="alert" className="mt-3 text-ui-caption-lg leading-relaxed text-hot">
              {message}
            </p>
          )}
          <button type="submit" className={`${buttonClass("primary", "lg")} mt-5 w-full`}>
            登录
          </button>
        </form>
        <p className="mt-6 text-center text-ui-caption text-ink-4">
          <a href="/" className="hover:text-ink-2">
            回到 {SITE.name}
          </a>
        </p>
      </div>
    </div>
  );
}
