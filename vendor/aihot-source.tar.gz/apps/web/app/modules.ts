// What a module's web.tsx (modules/<name>/web.tsx) may add to the engine's pages: navigation entries and
// the parts of a few pages that leave room for them. Its own pages come from its module.ts (routes.ts).
// The site's list is read through site-modules.ts.
//
// Every page loads web.tsx. A part only one page draws is given as its loader (`Part`), so it ships with that
// page's code: the page waits for its parts while its own code loads (site-modules.ts `loadParts`) and then
// renders them like any import.
import type { ComponentType, ReactNode } from "react";
import type { TopicSummary } from "@aihot/contracts/site";
import type { NavItem, Tab } from "./components/shell/nav";
import type { Text } from "./lib/i18n";

export type Part<T> = () => Promise<{ default: T }>;

/** What each panel of the agent page, and each module's part drawn on it, is given (routes/agent.tsx). */
export interface AgentPanelProps {
  /** The site's public address, read on the server so the page and the browser agree. */
  base: string;
  /** The value of the tag on what visitors copy (AgentPart.tag) as it is now; null on a site without one. */
  tag: string | null;
}

/** A way in on the agent page: a card in its chooser and a tab (`?tab=<key>`) with its panel. */
export interface AgentTrack {
  key: string;
  /** On its card and in the aside's list. */
  name: string;
  /** Where the page and the 我的 page list the ways in a few words. */
  short: string;
  badge?: Text;
  pitch: Text;
  /** What it suits, under the pitch. */
  fit: Text;
  icon: ComponentType<{ size?: number }>;
  Panel: ComponentType<AgentPanelProps>;
  /** Ids of sections in its panel: the page's address with one as its fragment opens this tab and scrolls there. */
  anchors?: string[];
}

/**
 * A tag on everything the agent page's visitors copy, so their use of each way in can be told apart: copied
 * addresses carry it as a query parameter, the curl commands in their User-Agent, and panels get its value.
 */
export interface CopyTag {
  /** A hook giving its value: the same on the server and in the first render, this browser's once the page runs. */
  useValue: () => string;
  /** The query parameter of copied addresses. */
  query: string;
  /** Its product in the copied curl commands' User-Agent. */
  userAgent: (value: string) => string;
  /** What it is: under the chooser, under the MCP address and under the feeds. */
  Note: ComponentType;
  mcp: Text;
  rss: Text;
}

/** Links from a module's part of the agent page into a panel's section. */
export interface AgentLinks {
  /** The page's address that opens the panel holding the section `anchor` and scrolls there. */
  href: (anchor: string) => string;
  /** Does the same without leaving the page. */
  open: (anchor: string) => void;
}

/** A module's part of the agent page (routes/agent.tsx, features/agent/panels.tsx). */
export interface AgentPart {
  /** Ways in of its own, ahead of the engine's MCP, RSS and API. */
  tracks?: AgentTrack[];
  /** The tag on what visitors copy; the first module's is used. */
  tag?: CopyTag;
  /** Between the page's header and the chooser. */
  Banner?: ComponentType<AgentPanelProps & AgentLinks>;
  /** Sections at the end of a track's panel (`track` is its key); `anchor`, the section's id, opens it like the track's own. */
  blocks?: Array<{ track: string; anchor: string; Block: ComponentType<AgentPanelProps> }>;
  /** Its clients built on the Agent guide, by name: named next to the guide in the resources and in the API panel's table. */
  guideClients?: string[];
  /** The aside's resources, after the engine's: [label, address, what it is for]. */
  resources?: Array<[label: Text, href: string, note: Text]>;
  /** The MCP panel's tool table: its tools. */
  tools?: Array<{ name: string; does: Text; ask: Text }>;
  /** The MCP panel's 连不上怎么办: entries after the engine's first. */
  mcpTroubles?: Text[];
  /** What the RSS panel's opening sentence goes on to say, a clause each after "；". */
  rssLead?: Text[];
  /** The API panel's table: a group of its addresses. */
  api?: { group: Text; rows: Array<[path: string, does: Text, often: Text]> };
  /** The API panel's usage tabs: one each, after the engine's. */
  recipes?: Array<{ key: string; label: Text; Body: ComponentType<{ base: string; curl: string }> }>;
  /** The API panel's 出错了怎么办: [status, what to do], after the engine's. */
  apiErrors?: Array<[status: Text, what: ReactNode]>;
}

/** A module's part of a topic page (routes/topic.tsx), from what its server module's topics.page returned for it. */
export interface TopicPagePart {
  /** What it is called: after "最新动态与" in the page's title, and in the name of its structured-data list. */
  name: Text;
  /** Whether it has anything on this page; without, the page leaves it out of its body and its head. */
  shows: (data: unknown, topic: TopicSummary) => boolean;
  /** Drawn between the page's header and its list. */
  Block: ComponentType<{ data: unknown; topic: TopicSummary }>;
  /** Its entries for the page's structured data, newest first; one with an event page links to it. */
  entries: (data: unknown) => Array<{ title: string; href: string | null }>;
  /** The headlines of its most important recent events: the search snippet leads with the first two. */
  news: (data: unknown) => string[];
}

/** Where the reader's account shows: the 我的 page's first row, the first row of the desktop sidebar's 更多 menu, the 收藏 page's note, the 卡册. */
export type AccountPlace = "me" | "menu" | "starred" | "album";

export interface WebModule {
  /** Its folder under modules/. */
  name: string;
  /** The reader's account, from a module that offers one, drawn where the place asks (before hydration: signed out). */
  account?: ComponentType<{ place: AccountPlace }>;
  /** The email of the reader signed in in this browser, or null (read after hydration). */
  signedInEmail?: () => string | null;
  /** Desktop sidebar: entries in a section between the engine's 内容 and 更多; modules sharing sectionKey (or section title) share it. */
  sidebar?: { sectionKey?: string; section: Text; items: NavItem[] };
  /** Phone tab bar: tabs before 我的. */
  tabs?: Tab[];
  /** The 我的 page: rows ahead of the engine's tools. */
  tools?: Array<{ to: string; label: Text; icon: ReactNode }>;
  /** Parts of every public page (root.tsx); the admin has its own chrome and gets none of them. */
  root?: {
    /** An inline script in <head>, after the theme's: it runs before the page paints. */
    bootScript?: string;
    /** Above the page's content. */
    Top?: ComponentType;
    /** After the page. */
    Bottom?: ComponentType;
    /** Headers for a counted page, sent to the API after its HTTP status is known. */
    documentHeaders?: (request: Request) => Record<string, string> | undefined;
  };
  agent?: Part<AgentPart>;
  topicPage?: Part<TopicPagePart>;
  /** Paths of the marks it serves that are drawn in white, for a dark tile (components/BrandMark.tsx). */
  darkMarks?: string[];
  /** The starred page (routes/starred.tsx): buttons ahead of 导入文件 that bring stars in from elsewhere, each resolving to the line it reports. */
  starredImports?: Array<{ label: Text; run: () => Promise<{ ok: boolean; text: Text }> }>;
  /**
   * The feedback page (routes/feedback.tsx): a draft kept elsewhere in this browser, read when the page
   * keeps none of its own ({ content, email, pageUrl }), and cleared once its own is saved or sent.
   */
  feedbackDraft?: { read: () => unknown; clear: () => void };
  /**
   * The feedback page opened from one of its buttons, a link carrying `state: { feedbackFor: <its name> }`: the
   * heading, the line under it, the example in the box and the tips beside the form, in place of the site's.
   * The link may also carry `content`, what the reader has already typed there: the page's box starts with it.
   */
  feedbackGuide?: { title: string; lead: string; example: string; tips: string[] };
  /** A press a page reports for the site's own counts (lib/clicks.ts): what was pressed, nothing about the reader. */
  onClick?: (target: string) => void;
  /** The terms page's footer: links after the engine's (routes/terms.tsx). */
  termsLinks?: Array<{ to: string; label: string }>;
  /** Its ways into the agent page (AgentPart.tracks) by their short names: the 我的 page's row names the first three (routes/more.tsx). */
  agentWays?: string[];
}

export function defineWebModule(module: WebModule): WebModule {
  return module;
}
